import '../../domain/finance/double_entry_engine.dart';

class FinanceExportService {
  /// Generates UTF-8 with BOM (\uFEFF) CSV string to ensure Excel displays Amharic properly.
  static String exportAccountsCsv(List<AccountModel> accounts, List<PostingModel> postings) {
    final buffer = StringBuffer('\uFEFF');
    buffer.writeln('"Account ID","Account Name","Type","Currency","Is Archived","Balance (ETB Cents)","Balance (ETB Decimal)","Created At"');

    for (final a in accounts) {
      final bal = DoubleEntryEngine.calculateAccountBalance(account: a, postings: postings);
      buffer.writeln('"${a.id}","${a.name.replaceAll('"', '""')}","${a.type.name}","${a.currencyCode}",${a.isArchived ? "TRUE" : "FALSE"},$bal,"${(bal / 100).toStringAsFixed(2)}","${a.createdAt.toIso8601String()}"');
    }
    return buffer.toString();
  }

  static String exportPartiesCsv(List<PartyModel> parties) {
    final buffer = StringBuffer('\uFEFF');
    buffer.writeln('"Party ID","Party Name","Phone","Notes","Is Archived","Created At"');

    for (final p in parties) {
      buffer.writeln('"${p.id}","${p.name.replaceAll('"', '""')}","${p.phone ?? ''}","${(p.notes ?? '').replaceAll('"', '""')}",${p.isArchived ? "TRUE" : "FALSE"},"${p.createdAt.toIso8601String()}"');
    }
    return buffer.toString();
  }

  static String exportJournalEntriesCsv(List<JournalEntryModel> entries) {
    final buffer = StringBuffer('\uFEFF');
    buffer.writeln('"Entry ID","Entry Type","Description","Occurrence Date","Is Voided","Void Reason","Created At"');

    for (final j in entries) {
      buffer.writeln('"${j.id}","${j.entryType.name}","${j.description.replaceAll('"', '""')}","${j.occurrenceDate}",${j.isVoided ? "TRUE" : "FALSE"},"${(j.voidReason ?? '').replaceAll('"', '""')}","${j.createdAt.toIso8601String()}"');
    }
    return buffer.toString();
  }

  static String exportPostingsCsv(List<PostingModel> postings) {
    final buffer = StringBuffer('\uFEFF');
    buffer.writeln('"Posting ID","Entry ID","Account ID","Amount Cents","Amount Decimal ETB","Direction","Movement Date","Category ID","Note"');

    for (final p in postings) {
      buffer.writeln('"${p.id}","${p.entryId}","${p.accountId}",${p.amountCents},"${(p.amountCents / 100).toStringAsFixed(2)}","${p.direction.name}","${p.accountMovementDate}","${p.categoryId ?? ''}","${(p.note ?? '').replaceAll('"', '""')}"');
    }
    return buffer.toString();
  }

  static String exportDebtsCsv(List<DebtModel> debts) {
    final buffer = StringBuffer('\uFEFF');
    buffer.writeln('"Debt ID","Origin Entry ID","Party ID","Debt Type","Principal Cents","Principal Decimal","Outstanding Cents","Outstanding Decimal","Due Date","Status","Created At"');

    for (final d in debts) {
      buffer.writeln('"${d.id}","${d.originEntryId}","${d.partyId}","${d.debtType.name}",${d.principalCents},"${(d.principalCents / 100).toStringAsFixed(2)}",${d.outstandingCents},"${(d.outstandingCents / 100).toStringAsFixed(2)}","${d.dueDate ?? ''}","${d.status.name}","${d.createdAt.toIso8601String()}"');
    }
    return buffer.toString();
  }

  static String exportSettlementAllocationsCsv(List<SettlementAllocationModel> allocations) {
    final buffer = StringBuffer('\uFEFF');
    buffer.writeln('"Allocation ID","Settlement Entry ID","Debt ID","Allocated Cents","Allocated Decimal","Settlement Date"');

    for (final a in allocations) {
      buffer.writeln('"${a.id}","${a.settlementEntryId}","${a.debtId}",${a.allocatedCents},"${(a.allocatedCents / 100).toStringAsFixed(2)}","${a.settlementDate}"');
    }
    return buffer.toString();
  }

  static String exportSqliteAnalyticalScript({
    required List<AccountModel> accounts,
    required List<PartyModel> parties,
    required List<JournalEntryModel> entries,
    required List<PostingModel> postings,
    required List<DebtModel> debts,
    required List<SettlementAllocationModel> allocations,
  }) {
    final buffer = StringBuffer();
    buffer.writeln('-- Daywell Personal Finance - Standalone SQLite Analytical Schema & Export');
    buffer.writeln('-- Generated: ${DateTime.now().toUtc().toIso8601String()}');
    buffer.writeln('PRAGMA foreign_keys = ON;\n');

    buffer.writeln('CREATE TABLE IF NOT EXISTS accounts (id TEXT PRIMARY KEY, name TEXT NOT NULL, type TEXT NOT NULL, currency_code TEXT NOT NULL, is_archived INTEGER NOT NULL, created_at TEXT NOT NULL);');
    buffer.writeln('CREATE TABLE IF NOT EXISTS parties (id TEXT PRIMARY KEY, name TEXT NOT NULL, phone TEXT, notes TEXT, is_archived INTEGER NOT NULL, created_at TEXT NOT NULL);');
    buffer.writeln('CREATE TABLE IF NOT EXISTS journal_entries (id TEXT PRIMARY KEY, entry_type TEXT NOT NULL, description TEXT NOT NULL, occurrence_date TEXT NOT NULL, is_voided INTEGER NOT NULL, void_reason TEXT, created_at TEXT NOT NULL);');
    buffer.writeln('CREATE TABLE IF NOT EXISTS postings (id TEXT PRIMARY KEY, entry_id TEXT NOT NULL, account_id TEXT NOT NULL, amount_cents INTEGER NOT NULL, direction TEXT NOT NULL, account_movement_date TEXT NOT NULL, category_id TEXT, note TEXT);');
    buffer.writeln('CREATE TABLE IF NOT EXISTS debts (id TEXT PRIMARY KEY, origin_entry_id TEXT NOT NULL, party_id TEXT NOT NULL, debt_type TEXT NOT NULL, principal_cents INTEGER NOT NULL, outstanding_cents INTEGER NOT NULL, due_date TEXT, status TEXT NOT NULL, created_at TEXT NOT NULL);');
    buffer.writeln('CREATE TABLE IF NOT EXISTS settlement_allocations (id TEXT PRIMARY KEY, settlement_entry_id TEXT NOT NULL, debt_id TEXT NOT NULL, allocated_cents INTEGER NOT NULL, settlement_date TEXT NOT NULL);\n');

    buffer.writeln('CREATE VIEW IF NOT EXISTS view_account_balances AS SELECT a.id, a.name, a.type, a.currency_code, SUM(CASE WHEN a.type IN (\'asset\', \'expense\') THEN CASE WHEN p.direction = \'debit\' THEN p.amount_cents ELSE -p.amount_cents END ELSE CASE WHEN p.direction = \'credit\' THEN p.amount_cents ELSE -p.amount_cents END END) AS balance_cents FROM accounts a LEFT JOIN postings p ON a.id = p.account_id GROUP BY a.id;\n');

    buffer.writeln('BEGIN TRANSACTION;');
    for (final a in accounts) {
      buffer.writeln('INSERT INTO accounts VALUES (\'${a.id}\', \'${a.name.replaceAll('\'', '\'\'')}\', \'${a.type.name}\', \'${a.currencyCode}\', ${a.isArchived ? 1 : 0}, \'${a.createdAt.toIso8601String()}\');');
    }
    for (final p in parties) {
      buffer.writeln('INSERT INTO parties VALUES (\'${p.id}\', \'${p.name.replaceAll('\'', '\'\'')}\', ${p.phone != null ? '\'${p.phone}\'' : 'NULL'}, ${p.notes != null ? '\'${p.notes!.replaceAll('\'', '\'\'')}\'' : 'NULL'}, ${p.isArchived ? 1 : 0}, \'${p.createdAt.toIso8601String()}\');');
    }
    for (final j in entries) {
      buffer.writeln('INSERT INTO journal_entries VALUES (\'${j.id}\', \'${j.entryType.name}\', \'${j.description.replaceAll('\'', '\'\'')}\', \'${j.occurrenceDate}\', ${j.isVoided ? 1 : 0}, ${j.voidReason != null ? '\'${j.voidReason!.replaceAll('\'', '\'\'')}\'' : 'NULL'}, \'${j.createdAt.toIso8601String()}\');');
    }
    for (final p in postings) {
      buffer.writeln('INSERT INTO postings VALUES (\'${p.id}\', \'${p.entryId}\', \'${p.accountId}\', ${p.amountCents}, \'${p.direction.name}\', \'${p.accountMovementDate}\', ${p.categoryId != null ? '\'${p.categoryId}\'' : 'NULL'}, ${p.note != null ? '\'${p.note!.replaceAll('\'', '\'\'')}\'' : 'NULL'});');
    }
    for (final d in debts) {
      buffer.writeln('INSERT INTO debts VALUES (\'${d.id}\', \'${d.originEntryId}\', \'${d.partyId}\', \'${d.debtType.name}\', ${d.principalCents}, ${d.outstandingCents}, ${d.dueDate != null ? '\'${d.dueDate}\'' : 'NULL'}, \'${d.status.name}\', \'${d.createdAt.toIso8601String()}\');');
    }
    for (final s in allocations) {
      buffer.writeln('INSERT INTO settlement_allocations VALUES (\'${s.id}\', \'${s.settlementEntryId}\', \'${s.debtId}\', ${s.allocatedCents}, \'${s.settlementDate}\');');
    }
    buffer.writeln('COMMIT;');
    return buffer.toString();
  }
}
