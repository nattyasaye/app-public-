import 'dart:convert';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';

/// Passphrase-derived encrypted backup engine.
///
/// Implements:
/// - Key Derivation: PBKDF2-HMAC-SHA256 with 100,000 iterations and a cryptographically random 16-byte salt
/// - Authenticated Encryption: AES-GCM-256 with a unique 12-byte Nonce/IV
/// - Integrity: SHA-256 digest of original plaintext database payload verified after decryption
/// - Portability: Self-contained envelope format readable across Android and iOS
class EncryptionBackupService {
  static const int _pbkdf2Iterations = 100000;
  static const int _keyLengthBits = 256;
  static const String currentAppVersion = '1.0.0';

  final AesGcm _cipher = AesGcm.with256bits();
  final Pbkdf2 _kdf = Pbkdf2(
    macAlgorithm: Hmac.sha256(),
    iterations: _pbkdf2Iterations,
    bits: _keyLengthBits,
  );

  /// Encrypts database JSON export payload using user's secret passphrase.
  Future<String> encryptDatabasePayload({
    required String rawDatabaseJson,
    required String passphrase,
    required int schemaVersion,
  }) async {
    // 1. Generate random 16-byte salt and 12-byte IV/Nonce
    final salt = SecretKeyData.random(length: 16).bytes;
    final nonce = _cipher.newNonce();

    // 2. Derive SecretKey using PBKDF2
    final derivedSecretKey = await _kdf.deriveKey(
      secretKey: SecretKey(utf8.encode(passphrase)),
      nonce: salt,
    );

    // 3. Compute SHA-256 checksum of plaintext for post-restore verification
    final sha256 = Sha256();
    final checksumSink = await sha256.hash(utf8.encode(rawDatabaseJson));
    final checksumHex = checksumSink.bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();

    // 4. Encrypt with AES-GCM-256
    final secretBox = await _cipher.encrypt(
      utf8.encode(rawDatabaseJson),
      secretKey: derivedSecretKey,
      nonce: nonce,
    );

    // 5. Structure portable encrypted envelope
    final envelope = {
      'header': {
        'format': 'personal_mgmt_encrypted_backup',
        'format_version': 1,
        'app_version': currentAppVersion,
        'schema_version': schemaVersion,
        'created_at_utc': DateTime.now().toUtc().toIso8601String(),
        'kdf': 'PBKDF2-HMAC-SHA256',
        'iterations': _pbkdf2Iterations,
        'salt_base64': base64Encode(salt),
        'nonce_base64': base64Encode(nonce),
        'mac_base64': base64Encode(secretBox.mac.bytes),
        'checksum_sha256': checksumHex,
      },
      'ciphertext_base64': base64Encode(secretBox.cipherText),
    };

    return jsonEncode(envelope);
  }

  /// Decrypts backup archive using user's passphrase and verifies integrity.
  Future<String> decryptDatabasePayload({
    required String encryptedEnvelopeJson,
    required String passphrase,
  }) async {
    final Map<String, dynamic> envelope = jsonDecode(encryptedEnvelopeJson);
    final header = envelope['header'] as Map<String, dynamic>;
    final ciphertextBase64 = envelope['ciphertext_base64'] as String;

    final salt = base64Decode(header['salt_base64']);
    final nonce = base64Decode(header['nonce_base64']);
    final macBytes = base64Decode(header['mac_base64']);
    final ciphertext = base64Decode(ciphertextBase64);
    final expectedChecksum = header['checksum_sha256'] as String;

    // 1. Re-derive key from passphrase and salt
    final derivedSecretKey = await _kdf.deriveKey(
      secretKey: SecretKey(utf8.encode(passphrase)),
      nonce: salt,
    );

    // 2. Decrypt SecretBox
    final secretBox = SecretBox(
      ciphertext,
      nonce: nonce,
      mac: Mac(macBytes),
    );

    final decryptedBytes = await _cipher.decrypt(
      secretBox,
      secretKey: derivedSecretKey,
    );

    final decryptedJson = utf8.decode(decryptedBytes);

    // 3. Verify cryptographic checksum
    final sha256 = Sha256();
    final checksumSink = await sha256.hash(decryptedBytes);
    final actualChecksum = checksumSink.bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();

    if (actualChecksum != expectedChecksum) {
      throw StateError('Backup integrity check failed: Checksum mismatch.');
    }

    return decryptedJson;
  }
}
