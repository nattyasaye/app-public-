import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'ui/app_state.dart';
import 'ui/screens/dashboard_view.dart';
import 'ui/screens/tasks_view.dart';
import 'ui/screens/finance_view.dart';
import 'ui/screens/notes_view.dart';
import 'ui/screens/backup_view.dart';
import 'ui/screens/more_view.dart';
import 'ui/widgets/quick_capture_dialog.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DaywellApp());
}

class DaywellApp extends StatelessWidget {
  const DaywellApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Daywell',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.system,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFFAF9F5),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1B4D3E),
          primary: const Color(0xFF1B4D3E),
          secondary: const Color(0xFFE0EFE8),
          brightness: Brightness.light,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFFAF9F5),
          elevation: 0,
          centerTitle: false,
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF121816),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF81C784),
          primary: const Color(0xFF81C784),
          secondary: const Color(0xFF1D382E),
          brightness: Brightness.dark,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF121816),
          elevation: 0,
          centerTitle: false,
        ),
      ),
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('en', 'US'),
        Locale('am', 'ET'),
      ],
      home: const MainDaywellScreen(),
    );
  }
}

class MainDaywellScreen extends StatefulWidget {
  const MainDaywellScreen({super.key});

  @override
  State<MainDaywellScreen> createState() => _MainDaywellScreenState();
}

class _MainDaywellScreenState extends State<MainDaywellScreen> {
  int _currentTabIndex = 0; // 0: Today, 1: Tasks, 2: Projects, 3: More
  String? _activeSubScreen; // 'finance', 'notes', 'backup'
  late final AppStateManager _state;

  static const MethodChannel _quickCaptureChannel =
      MethodChannel('com.example.personalmanagement/quick_capture');

  @override
  void initState() {
    super.initState();
    _state = AppStateManager();
    _setupMethodChannelListener();
    _checkInitialIntentTriggers();
  }

  void _setupMethodChannelListener() {
    _quickCaptureChannel.setMethodCallHandler((call) async {
      if (call.method == 'onQuickCaptureTriggered') {
        _openQuickCapture();
      } else if (call.method == 'onTextShared') {
        final text = call.arguments as String?;
        if (text != null && text.isNotEmpty) {
          _openQuickCapture(initialText: text);
        }
      }
    });
  }

  Future<void> _checkInitialIntentTriggers() async {
    try {
      final isTriggered = await _quickCaptureChannel.invokeMethod<bool>('checkQuickCaptureTrigger');
      if (isTriggered == true) {
        _openQuickCapture();
      }
      final sharedText = await _quickCaptureChannel.invokeMethod<String?>('getSharedText');
      if (sharedText != null && sharedText.isNotEmpty) {
        _openQuickCapture(initialText: sharedText);
      }
    } catch (_) {}
  }

  void _openQuickCapture({String? initialText}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => QuickCaptureDialog(
        state: _state,
        initialText: initialText,
      ),
    );
  }

  void _onNavigateTab(int index) {
    setState(() {
      _currentTabIndex = index;
      _activeSubScreen = null;
    });
  }

  void _onNavigateSubScreen(String route) {
    setState(() {
      if (route == 'today') {
        _currentTabIndex = 0;
        _activeSubScreen = null;
      } else if (route == 'tasks') {
        _currentTabIndex = 1;
        _activeSubScreen = null;
      } else if (route == 'projects') {
        _currentTabIndex = 2;
        _activeSubScreen = null;
      } else {
        _activeSubScreen = route; // 'finance', 'notes', 'backup'
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _state,
      builder: (context, _) {
        Widget currentBody;

        if (_activeSubScreen == 'finance') {
          currentBody = FinanceView(state: _state);
        } else if (_activeSubScreen == 'notes') {
          currentBody = NotesView(state: _state);
        } else if (_activeSubScreen == 'backup') {
          currentBody = BackupView(state: _state);
        } else {
          switch (_currentTabIndex) {
            case 0:
              currentBody = DashboardView(
                state: _state,
                onOpenQuickCapture: () => _openQuickCapture(),
                onNavigateTab: (idx) {
                  if (idx == 2) {
                    _onNavigateSubScreen('finance');
                  } else if (idx == 3) {
                    _onNavigateSubScreen('notes');
                  } else if (idx == 4) {
                    _onNavigateSubScreen('backup');
                  } else {
                    _onNavigateTab(idx);
                  }
                },
              );
              break;
            case 1:
              currentBody = TasksView(state: _state);
              break;
            case 2:
              currentBody = TasksView(state: _state); // Project view subtab
              break;
            case 3:
            default:
              currentBody = MoreView(
                state: _state,
                onNavigateSubScreen: _onNavigateSubScreen,
              );
              break;
          }
        }

        return Scaffold(
          body: currentBody,
          bottomNavigationBar: NavigationBar(
            selectedIndex: _currentTabIndex,
            onDestinationSelected: _onNavigateTab,
            backgroundColor: Theme.of(context).cardColor,
            elevation: 2,
            indicatorColor: const Color(0xFFE0EFE8),
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.calendar_today_outlined, size: 20),
                selectedIcon: Icon(Icons.calendar_today_rounded, size: 20, color: Color(0xFF1B4D3E)),
                label: 'Today',
              ),
              NavigationDestination(
                icon: Icon(Icons.check_circle_outline_rounded, size: 20),
                selectedIcon: Icon(Icons.check_circle_rounded, size: 20, color: Color(0xFF1B4D3E)),
                label: 'Tasks',
              ),
              NavigationDestination(
                icon: Icon(Icons.layers_outlined, size: 20),
                selectedIcon: Icon(Icons.layers_rounded, size: 20, color: Color(0xFF1B4D3E)),
                label: 'Projects',
              ),
              NavigationDestination(
                icon: Icon(Icons.grid_view_outlined, size: 20),
                selectedIcon: Icon(Icons.grid_view_rounded, size: 20, color: Color(0xFF1B4D3E)),
                label: 'More',
              ),
            ],
          ),
        );
      },
    );
  }
}
