import 'package:uuid/uuid.dart';
import '../database/app_database.dart';

/// Contract for managing tasks in Drift SQLite.
abstract class ITaskRepository {
  Future<List<Task>> getTasks({
    String? status,
    String? priority,
    String? projectId,
    bool? isOverdue,
  });

  Future<Task> createTask({
    required String title,
    String? description,
    String priority = 'medium',
    DateTime? dueDate,
    DateTime? scheduledDate,
    int? estimatedDurationMinutes,
    String? projectId,
    String? milestoneId,
  });

  Future<void> updateTaskStatus(String id, String newStatus);
  Future<void> rescheduleTask(String id, DateTime? newDueDate);
  Future<void> postponeTaskDays(String id, int days);
  Future<void> cancelTask(String id);
  Future<void> deleteTask(String id);
  Future<List<Task>> getTasksForProject(String projectId);
}

/// Drift SQLite implementation of [ITaskRepository].
class DriftTaskRepository implements ITaskRepository {
  final AppDatabase _db;
  final Uuid _uuid = const Uuid();

  DriftTaskRepository(this._db);

  @override
  Future<List<Task>> getTasks({
    String? status,
    String? priority,
    String? projectId,
    bool? isOverdue,
  }) async {
    final query = _db.select(_db.tasks);

    if (status != null) {
      query.where((tbl) => tbl.status.equals(status));
    }
    if (priority != null) {
      query.where((tbl) => tbl.priority.equals(priority));
    }
    if (projectId != null) {
      query.where((tbl) => tbl.projectId.equals(projectId));
    }
    if (isOverdue == true) {
      final now = DateTime.now().toUtc();
      query.where((tbl) =>
          tbl.dueDate.isNotNull() &
          tbl.dueDate.isSmallerThanValue(now) &
          tbl.status.isNotIn(['completed', 'cancelled']));
    }

    query.orderBy([(tbl) => OrderingTerm.asc(tbl.dueDate), (tbl) => OrderingTerm.desc(tbl.priority)]);
    return query.get();
  }

  @override
  Future<Task> createTask({
    required String title,
    String? description,
    String priority = 'medium',
    DateTime? dueDate,
    DateTime? scheduledDate,
    int? estimatedDurationMinutes,
    String? projectId,
    String? milestoneId,
  }) async {
    final id = _uuid.v4();
    final now = DateTime.now().toUtc();

    await _db.into(_db.tasks).insert(
      TasksCompanion.insert(
        id: id,
        title: title.trim(),
        description: Value(description?.trim()),
        status: const Value('not_started'),
        priority: Value(priority),
        dueDate: Value(dueDate?.toUtc()),
        scheduledDate: Value(scheduledDate?.toUtc()),
        estimatedDurationMinutes: Value(estimatedDurationMinutes),
        projectId: Value(projectId),
        milestoneId: Value(milestoneId),
        createdAt: now,
        updatedAt: now,
      ),
    );

    return (_db.select(_db.tasks)..where((tbl) => tbl.id.equals(id))).getSingle();
  }

  @override
  Future<void> updateTaskStatus(String id, String newStatus) async {
    await (_db.update(_db.tasks)..where((tbl) => tbl.id.equals(id))).write(
      TasksCompanion(
        status: Value(newStatus),
        updatedAt: Value(DateTime.now().toUtc()),
      ),
    );
  }

  @override
  Future<void> rescheduleTask(String id, DateTime? newDueDate) async {
    await (_db.update(_db.tasks)..where((tbl) => tbl.id.equals(id))).write(
      TasksCompanion(
        dueDate: Value(newDueDate?.toUtc()),
        updatedAt: Value(DateTime.now().toUtc()),
      ),
    );
  }

  @override
  Future<void> postponeTaskDays(String id, int days) async {
    final task = await (_db.select(_db.tasks)..where((tbl) => tbl.id.equals(id))).getSingleOrNull();
    if (task == null) return;

    final currentDue = task.dueDate ?? DateTime.now().toUtc();
    final newDue = currentDue.add(Duration(days: days));

    await rescheduleTask(id, newDue);
  }

  @override
  Future<void> cancelTask(String id) async {
    await updateTaskStatus(id, 'cancelled');
  }

  @override
  Future<void> deleteTask(String id) async {
    await (_db.delete(_db.tasks)..where((tbl) => tbl.id.equals(id))).go();
  }

  @override
  Future<List<Task>> getTasksForProject(String projectId) async {
    return (_db.select(_db.tasks)..where((tbl) => tbl.projectId.equals(projectId))).get();
  }
}
