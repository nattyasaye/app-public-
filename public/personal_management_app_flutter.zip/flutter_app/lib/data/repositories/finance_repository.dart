import 'package:uuid/uuid.dart';
import '../database/app_database.dart';
import '../../domain/finance/financial_engine.dart';

/// Financial repository contract implementing decimal-safe minor-unit accounting
/// and transaction correction history.
abstract class IFinanceRepository {
  Future<List<FinancialCategory>> getCategories();
  Future<List<FinancialTransaction>> getTransactions({DateTime? startDate, DateTime? endDate});

  Future<FinancialTransaction> recordTransaction({
    required String categoryId,
    required int amountCents,
    required String type, // 'income' | 'expense'
    required DateTime transactionDate,
    String? note,
    String? payee,
  });

  /// Corrects a transaction by recording an adjusted version while preserving historical trace
  Future<FinancialTransaction> correctTransaction({
    required String originalTransactionId,
    required int newAmountCents,
    required String newCategoryId,
    required String correctionReason,
    String? newNote,
    String? newPayee,
  });

  Future<List<FinancialCommitment>> getCommitments({bool? isPaid});
  Future<FinancialCommitment> addCommitment({
    required String title,
    required int amountCents,
    required DateTime dueDate,
    String? recurringRule,
  });
  Future<void> markCommitmentPaid(String commitmentId, {bool createExpenseTransaction = false});

  Future<List<SavingsGoal>> getSavingsGoals();
  Future<SavingsGoal> createSavingsGoal({
    required String title,
    required int targetCents,
    int initialAllocatedCents = 0,
    DateTime? targetDate,
  });
  Future<void> updateSavingsAllocation(String goalId, int newAllocatedCents);

  Future<FinancialSnapshot> getFinancialSnapshot({
    required int openingBalanceCents,
    required DateTime periodStart,
    required DateTime periodEnd,
    required List<int> expectedFutureIncomeCents,
  });
}

/// Drift SQLite implementation of [IFinanceRepository]
class DriftFinanceRepository implements IFinanceRepository {
  final AppDatabase _db;
  final Uuid _uuid = const Uuid();

  DriftFinanceRepository(this._db);

  @override
  Future<List<FinancialCategory>> getCategories() async {
    return _db.select(_db.financialCategories).get();
  }

  @override
  Future<List<FinancialTransaction>> getTransactions({DateTime? startDate, DateTime? endDate}) async {
    final query = _db.select(_db.financialTransactions);
    if (startDate != null) {
      query.where((tbl) => tbl.transactionDate.isBiggerOrEqualValue(startDate.toUtc()));
    }
    if (endDate != null) {
      query.where((tbl) => tbl.transactionDate.isSmallerOrEqualValue(endDate.toUtc()));
    }
    query.orderBy([(tbl) => OrderingTerm.desc(tbl.transactionDate)]);
    return query.get();
  }

  @override
  Future<FinancialTransaction> recordTransaction({
    required String categoryId,
    required int amountCents,
    required String type,
    required DateTime transactionDate,
    String? note,
    String? payee,
  }) async {
    final id = _uuid.v4();
    final now = DateTime.now().toUtc();

    await _db.into(_db.financialTransactions).insert(
      FinancialTransactionsCompanion.insert(
        id: id,
        categoryId: categoryId,
        amountCents: amountCents.abs(),
        type: type,
        transactionDate: transactionDate.toUtc(),
        note: Value(note?.trim()),
        payee: Value(payee?.trim()),
        createdAt: now,
      ),
    );

    return (_db.select(_db.financialTransactions)..where((tbl) => tbl.id.equals(id))).getSingle();
  }

  @override
  Future<FinancialTransaction> correctTransaction({
    required String originalTransactionId,
    required int newAmountCents,
    required String newCategoryId,
    required String correctionReason,
    String? newNote,
    String? newPayee,
  }) async {
    final original = await (_db.select(_db.financialTransactions)
          ..where((tbl) => tbl.id.equals(originalTransactionId)))
        .getSingle();

    final newId = _uuid.v4();
    final now = DateTime.now().toUtc();

    // Insert correction entry with reference to original
    final correctionNote = '[Corrected from ${original.id.substring(0, 8)}: $correctionReason] ${newNote ?? original.note ?? ''}';

    await _db.into(_db.financialTransactions).insert(
      FinancialTransactionsCompanion.insert(
        id: newId,
        categoryId: newCategoryId,
        amountCents: newAmountCents.abs(),
        type: original.type,
        transactionDate: original.transactionDate,
        note: Value(correctionNote.trim()),
        payee: Value(newPayee ?? original.payee),
        createdAt: now,
      ),
    );

    // Annotate original transaction as superseded rather than silently deleting it
    await (_db.update(_db.financialTransactions)..where((tbl) => tbl.id.equals(original.id))).write(
      FinancialTransactionsCompanion(
        note: Value('[Superseded by ${newId.substring(0, 8)}] ${original.note ?? ''}'),
      ),
    );

    return (_db.select(_db.financialTransactions)..where((tbl) => tbl.id.equals(newId))).getSingle();
  }

  @override
  Future<List<FinancialCommitment>> getCommitments({bool? isPaid}) async {
    final query = _db.select(_db.financialCommitments);
    if (isPaid != null) {
      query.where((tbl) => tbl.isPaid.equals(isPaid));
    }
    query.orderBy([(tbl) => OrderingTerm.asc(tbl.dueDate)]);
    return query.get();
  }

  @override
  Future<FinancialCommitment> addCommitment({
    required String title,
    required int amountCents,
    required DateTime dueDate,
    String? recurringRule,
  }) async {
    final id = _uuid.v4();
    final now = DateTime.now().toUtc();

    await _db.into(_db.financialCommitments).insert(
      FinancialCommitmentsCompanion.insert(
        id: id,
        title: title.trim(),
        amountCents: amountCents.abs(),
        dueDate: dueDate.toUtc(),
        isPaid: const Value(false),
        recurringRule: Value(recurringRule),
        createdAt: now,
      ),
    );

    return (_db.select(_db.financialCommitments)..where((tbl) => tbl.id.equals(id))).getSingle();
  }

  @override
  Future<void> markCommitmentPaid(String commitmentId, {bool createExpenseTransaction = false}) async {
    final commitment = await (_db.select(_db.financialCommitments)..where((tbl) => tbl.id.equals(commitmentId))).getSingle();

    await (_db.update(_db.financialCommitments)..where((tbl) => tbl.id.equals(commitmentId))).write(
      const FinancialCommitmentsCompanion(isPaid: Value(true)),
    );

    if (createExpenseTransaction) {
      // Find default expense category
      final defaultCat = await (_db.select(_db.financialCategories)
            ..where((tbl) => tbl.type.equals('expense'))
            ..limit(1))
          .getSingleOrNull();

      if (defaultCat != null) {
        await recordTransaction(
          categoryId: defaultCat.id,
          amountCents: commitment.amountCents,
          type: 'expense',
          transactionDate: DateTime.now().toUtc(),
          note: 'Payment for commitment: ${commitment.title}',
          payee: commitment.title,
        );
      }
    }
  }

  @override
  Future<List<SavingsGoal>> getSavingsGoals() async {
    return _db.select(_db.savingsGoals).get();
  }

  @override
  Future<SavingsGoal> createSavingsGoal({
    required String title,
    required int targetCents,
    int initialAllocatedCents = 0,
    DateTime? targetDate,
  }) async {
    final id = _uuid.v4();
    final now = DateTime.now().toUtc();

    await _db.into(_db.savingsGoals).insert(
      SavingsGoalsCompanion.insert(
        id: id,
        title: title.trim(),
        targetCents: targetCents.abs(),
        currentAllocatedCents: Value(initialAllocatedCents.abs()),
        targetDate: Value(targetDate?.toUtc()),
        createdAt: now,
      ),
    );

    return (_db.select(_db.savingsGoals)..where((tbl) => tbl.id.equals(id))).getSingle();
  }

  @override
  Future<void> updateSavingsAllocation(String goalId, int newAllocatedCents) async {
    await (_db.update(_db.savingsGoals)..where((tbl) => tbl.id.equals(goalId))).write(
      SavingsGoalsCompanion(
        currentAllocatedCents: Value(newAllocatedCents.abs()),
      ),
    );
  }

  @override
  Future<FinancialSnapshot> getFinancialSnapshot({
    required int openingBalanceCents,
    required DateTime periodStart,
    required DateTime periodEnd,
    required List<int> expectedFutureIncomeCents,
  }) async {
    // 1. Fetch valid transactions (excluding superseded ones if marked)
    final allTx = await _db.select(_db.financialTransactions).get();
    final incomeCents = <int>[];
    final expenseCents = <int>[];

    for (final tx in allTx) {
      // Exclude superseded transactions from active balance sum
      if (tx.note != null && tx.note!.startsWith('[Superseded by')) continue;

      if (tx.type == 'income') {
        incomeCents.add(tx.amountCents);
      } else if (tx.type == 'expense') {
        expenseCents.add(tx.amountCents);
      }
    }

    // 2. Unpaid commitments due within the period
    final commitments = await (_db.select(_db.financialCommitments)
          ..where((tbl) =>
              tbl.isPaid.equals(false) &
              tbl.dueDate.isBiggerOrEqualValue(periodStart.toUtc()) &
              tbl.dueDate.isSmallerOrEqualValue(periodEnd.toUtc())))
        .get();
    final unpaidCommitmentsCents = commitments.map((c) => c.amountCents).toList();

    // 3. Savings allocations
    final savings = await _db.select(_db.savingsGoals).get();
    final savingsAllocationsCents = savings.map((s) => s.currentAllocatedCents).toList();

    return FinancialEngine.computeSnapshot(
      openingBalanceCents: openingBalanceCents,
      receivedIncomeCents: incomeCents,
      recordedExpenseCents: expenseCents,
      unpaidCommitmentsInPeriodCents: unpaidCommitmentsCents,
      savingsAllocationsInPeriodCents: savingsAllocationsCents,
      expectedFutureIncomeCents: expectedFutureIncomeCents,
    );
  }
}
