import 'package:uuid/uuid.dart';
import '../database/app_database.dart';

/// Repository interface for Inbox persistence and operations.
abstract class IInboxRepository {
  Future<List<InboxItem>> getAllInboxItems({bool includeProcessed = false});
  Stream<List<InboxItem>> watchUnprocessedItems();
  Future<InboxItem> captureQuickThought(String rawText, {String category = 'general'});
  Future<void> markProcessed(String id);
  Future<void> deleteItem(String id);
  Future<void> updateItemText(String id, String newText, {String? category});
}

/// Drift implementation of [IInboxRepository].
class DriftInboxRepository implements IInboxRepository {
  final AppDatabase _db;
  final Uuid _uuid = const Uuid();

  DriftInboxRepository(this._db);

  @override
  Future<List<InboxItem>> getAllInboxItems({bool includeProcessed = false}) async {
    final query = _db.select(_db.inboxItems);
    if (!includeProcessed) {
      query.where((tbl) => tbl.isProcessed.equals(false));
    }
    query.orderBy([(tbl) => OrderingTerm.desc(tbl.createdAt)]);
    return query.get();
  }

  @override
  Stream<List<InboxItem>> watchUnprocessedItems() {
    return (_db.select(_db.inboxItems)
          ..where((tbl) => tbl.isProcessed.equals(false))
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.createdAt)]))
        .watch();
  }

  @override
  Future<InboxItem> captureQuickThought(String rawText, {String category = 'general'}) async {
    final id = _uuid.v4();
    final now = DateTime.now().toUtc();

    await _db.into(_db.inboxItems).insert(
      InboxItemsCompanion.insert(
        id: id,
        rawText: rawText.trim(),
        category: Value(category),
        isProcessed: const Value(false),
        createdAt: now,
      ),
    );

    return (_db.select(_db.inboxItems)..where((tbl) => tbl.id.equals(id))).getSingle();
  }

  @override
  Future<void> markProcessed(String id) async {
    await (_db.update(_db.inboxItems)..where((tbl) => tbl.id.equals(id))).write(
      const InboxItemsCompanion(isProcessed: Value(true)),
    );
  }

  @override
  Future<void> deleteItem(String id) async {
    await (_db.delete(_db.inboxItems)..where((tbl) => tbl.id.equals(id))).go();
  }

  @override
  Future<void> updateItemText(String id, String newText, {String? category}) async {
    await (_db.update(_db.inboxItems)..where((tbl) => tbl.id.equals(id))).write(
      InboxItemsCompanion(
        rawText: Value(newText.trim()),
        category: category != null ? Value(category) : const Value.absent(),
      ),
    );
  }
}
