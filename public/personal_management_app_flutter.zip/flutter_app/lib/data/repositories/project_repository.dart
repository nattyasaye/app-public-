import 'package:uuid/uuid.dart';
import '../database/app_database.dart';
import '../../domain/projects/progress_engine.dart';

class ProjectWithProgress {
  final Project project;
  final Goal? goal;
  final List<Task> tasks;
  final List<Milestone> milestones;
  final int progressPercentage;

  const ProjectWithProgress({
    required this.project,
    this.goal,
    required this.tasks,
    required this.milestones,
    required this.progressPercentage,
  });
}

abstract class IProjectRepository {
  Future<List<Goal>> getAllGoals();
  Future<Goal> createGoal({required String title, String? description, DateTime? targetDate});

  Future<List<ProjectWithProgress>> getAllProjectsWithProgress();
  Future<Project> createProject({
    required String title,
    String? goalId,
    String? description,
    DateTime? targetDate,
  });

  Future<Milestone> addMilestone({
    required String projectId,
    required String title,
    DateTime? dueDate,
  });
  Future<void> toggleMilestone(String milestoneId, bool isCompleted);
}

class DriftProjectRepository implements IProjectRepository {
  final AppDatabase _db;
  final Uuid _uuid = const Uuid();

  DriftProjectRepository(this._db);

  @override
  Future<List<Goal>> getAllGoals() async {
    return _db.select(_db.goals).get();
  }

  @override
  Future<Goal> createGoal({required String title, String? description, DateTime? targetDate}) async {
    final id = _uuid.v4();
    final now = DateTime.now().toUtc();

    await _db.into(_db.goals).insert(
      GoalsCompanion.insert(
        id: id,
        title: title.trim(),
        description: Value(description?.trim()),
        targetDate: Value(targetDate?.toUtc()),
        status: const Value('active'),
        createdAt: now,
      ),
    );

    return (_db.select(_db.goals)..where((tbl) => tbl.id.equals(id))).getSingle();
  }

  @override
  Future<List<ProjectWithProgress>> getAllProjectsWithProgress() async {
    final projects = await _db.select(_db.projects).get();
    final results = <ProjectWithProgress>[];

    for (final proj in projects) {
      Goal? goal;
      if (proj.goalId != null) {
        goal = await (_db.select(_db.goals)..where((tbl) => tbl.id.equals(proj.goalId!))).getSingleOrNull();
      }

      final tasks = await (_db.select(_db.tasks)..where((tbl) => tbl.projectId.equals(proj.id))).get();
      final milestones = await (_db.select(_db.milestones)..where((tbl) => tbl.projectId.equals(proj.id))).get();

      final completedTasks = tasks.where((t) => t.status == 'completed').length;
      final completedMilestones = milestones.where((m) => m.isCompleted).length;

      final progress = ProgressEngine.calculateProgressPercentage(
        totalTasks: tasks.length,
        completedTasks: completedTasks,
        totalMilestones: milestones.length,
        completedMilestones: completedMilestones,
        isProjectManuallyCompleted: proj.status == 'completed',
      );

      results.add(ProjectWithProgress(
        project: proj,
        goal: goal,
        tasks: tasks,
        milestones: milestones,
        progressPercentage: progress,
      ));
    }

    return results;
  }

  @override
  Future<Project> createProject({
    required String title,
    String? goalId,
    String? description,
    DateTime? targetDate,
  }) async {
    final id = _uuid.v4();
    final now = DateTime.now().toUtc();

    await _db.into(_db.projects).insert(
      ProjectsCompanion.insert(
        id: id,
        title: title.trim(),
        goalId: Value(goalId),
        description: Value(description?.trim()),
        targetDate: Value(targetDate?.toUtc()),
        status: const Value('active'),
        createdAt: now,
      ),
    );

    return (_db.select(_db.projects)..where((tbl) => tbl.id.equals(id))).getSingle();
  }

  @override
  Future<Milestone> addMilestone({
    required String projectId,
    required String title,
    DateTime? dueDate,
  }) async {
    final id = _uuid.v4();
    final now = DateTime.now().toUtc();

    await _db.into(_db.milestones).insert(
      MilestonesCompanion.insert(
        id: id,
        projectId: projectId,
        title: title.trim(),
        dueDate: Value(dueDate?.toUtc()),
        isCompleted: const Value(false),
        createdAt: now,
      ),
    );

    return (_db.select(_db.milestones)..where((tbl) => tbl.id.equals(id))).getSingle();
  }

  @override
  Future<void> toggleMilestone(String milestoneId, bool isCompleted) async {
    await (_db.update(_db.milestones)..where((tbl) => tbl.id.equals(milestoneId))).write(
      MilestonesCompanion(isCompleted: Value(isCompleted)),
    );
  }
}
