import 'package:uuid/uuid.dart';
import '../database/app_database.dart';

/// Contract for managing personal notes, reflections, and reference records.
abstract class INoteRepository {
  Future<List<Note>> getNotes({String? category, String? projectId, String? goalId});
  Future<Note> createNote({
    required String title,
    required String content,
    String category = 'general',
    String? projectId,
    String? goalId,
  });
  Future<void> updateNote({
    required String id,
    required String title,
    required String content,
    String? category,
  });
  Future<void> deleteNote(String id);
  Future<List<Note>> searchNotes(String query);
}

/// Drift SQLite implementation of [INoteRepository].
class DriftNoteRepository implements INoteRepository {
  final AppDatabase _db;
  final Uuid _uuid = const Uuid();

  DriftNoteRepository(this._db);

  @override
  Future<List<Note>> getNotes({String? category, String? projectId, String? goalId}) async {
    final query = _db.select(_db.notes);
    if (category != null) {
      query.where((tbl) => tbl.category.equals(category));
    }
    if (projectId != null) {
      query.where((tbl) => tbl.projectId.equals(projectId));
    }
    if (goalId != null) {
      query.where((tbl) => tbl.goalId.equals(goalId));
    }
    query.orderBy([(tbl) => OrderingTerm.desc(tbl.updatedAt)]);
    return query.get();
  }

  @override
  Future<Note> createNote({
    required String title,
    required String content,
    String category = 'general',
    String? projectId,
    String? goalId,
  }) async {
    final id = _uuid.v4();
    final now = DateTime.now().toUtc();

    await _db.into(_db.notes).insert(
      NotesCompanion.insert(
        id: id,
        title: title.trim(),
        content: content.trim(),
        category: Value(category),
        projectId: Value(projectId),
        goalId: Value(goalId),
        createdAt: now,
        updatedAt: now,
      ),
    );

    return (_db.select(_db.notes)..where((tbl) => tbl.id.equals(id))).getSingle();
  }

  @override
  Future<void> updateNote({
    required String id,
    required String title,
    required String content,
    String? category,
  }) async {
    await (_db.update(_db.notes)..where((tbl) => tbl.id.equals(id))).write(
      NotesCompanion(
        title: Value(title.trim()),
        content: Value(content.trim()),
        category: category != null ? Value(category) : const Value.absent(),
        updatedAt: Value(DateTime.now().toUtc()),
      ),
    );
  }

  @override
  Future<void> deleteNote(String id) async {
    await (_db.delete(_db.notes)..where((tbl) => tbl.id.equals(id))).go();
  }

  @override
  Future<List<Note>> searchNotes(String query) async {
    final clean = query.trim().toLowerCase();
    if (clean.isEmpty) return [];

    return (_db.select(_db.notes)
          ..where((tbl) =>
              tbl.title.lower().like('%$clean%') |
              tbl.content.lower().like('%$clean%'))
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.updatedAt)]))
        .get();
  }
}
