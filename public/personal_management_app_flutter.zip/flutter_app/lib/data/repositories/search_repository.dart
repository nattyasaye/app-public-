import '../database/app_database.dart';

/// Unified search result item across all entities
class SearchResultItem {
  final String id;
  final String title;
  final String? snippet;
  final String entityType; // 'inbox' | 'task' | 'note' | 'project' | 'commitment'
  final DateTime timestampUtc;

  const SearchResultItem({
    required this.id,
    required this.title,
    this.snippet,
    required this.entityType,
    required this.timestampUtc,
  });
}

/// Abstract contract for offline local search
abstract class ISearchRepository {
  Future<List<SearchResultItem>> searchAll(String query, {String? entityFilter});
}

/// Drift SQLite implementation of offline local search
class DriftSearchRepository implements ISearchRepository {
  final AppDatabase _db;

  DriftSearchRepository(this._db);

  @override
  Future<List<SearchResultItem>> searchAll(String query, {String? entityFilter}) async {
    final cleanQuery = query.trim().toLowerCase();
    if (cleanQuery.isEmpty) return [];

    final results = <SearchResultItem>[];

    // 1. Search Inbox Items
    if (entityFilter == null || entityFilter == 'inbox') {
      final inboxMatches = await (_db.select(_db.inboxItems)
            ..where((tbl) => tbl.rawText.lower().like('%$cleanQuery%')))
          .get();
      for (final item in inboxMatches) {
        results.add(SearchResultItem(
          id: item.id,
          title: item.rawText,
          snippet: 'Category: ${item.category} • ${item.isProcessed ? "Processed" : "Unprocessed"}',
          entityType: 'inbox',
          timestampUtc: item.createdAt,
        ));
      }
    }

    // 2. Search Tasks
    if (entityFilter == null || entityFilter == 'task') {
      final taskMatches = await (_db.select(_db.tasks)
            ..where((tbl) =>
                tbl.title.lower().like('%$cleanQuery%') |
                (tbl.description.isNotNull() & tbl.description.lower().like('%$cleanQuery%'))))
          .get();
      for (final task in taskMatches) {
        results.add(SearchResultItem(
          id: task.id,
          title: task.title,
          snippet: 'Priority: ${task.priority} • Status: ${task.status}',
          entityType: 'task',
          timestampUtc: task.updatedAt,
        ));
      }
    }

    // 3. Search Notes
    if (entityFilter == null || entityFilter == 'note') {
      final noteMatches = await (_db.select(_db.notes)
            ..where((tbl) =>
                tbl.title.lower().like('%$cleanQuery%') |
                tbl.content.lower().like('%$cleanQuery%')))
          .get();
      for (final note in noteMatches) {
        results.add(SearchResultItem(
          id: note.id,
          title: note.title,
          snippet: note.content.length > 80 ? '${note.content.substring(0, 80)}...' : note.content,
          entityType: 'note',
          timestampUtc: note.updatedAt,
        ));
      }
    }

    // 4. Search Commitments
    if (entityFilter == null || entityFilter == 'commitment') {
      final commitMatches = await (_db.select(_db.financialCommitments)
            ..where((tbl) => tbl.title.lower().like('%$cleanQuery%')))
          .get();
      for (final c in commitMatches) {
        results.add(SearchResultItem(
          id: c.id,
          title: c.title,
          snippet: '${c.amountCents ~/ 100} ETB • ${c.isPaid ? "Paid" : "Due"}',
          entityType: 'commitment',
          timestampUtc: c.createdAt,
        ));
      }
    }

    // Sort by timestamp descending
    results.sort((a, b) => b.timestampUtc.compareTo(a.timestampUtc));
    return results;
  }
}
