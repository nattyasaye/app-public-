import 'dart:io';
import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import 'tables.dart';

part 'app_database.g.dart';

@DriftDatabase(tables: [
  InboxItems,
  Goals,
  Projects,
  Milestones,
  Tasks,
  Notes,
  FinancialCategories,
  FinancialTransactions,
  FinancialCommitments,
  SavingsGoals,
  Reminders,
  AppSettings,
  AccountsTable,
  PartiesTable,
  JournalEntriesTable,
  PostingsTable,
  DebtsTable,
  SettlementAllocationsTable,
])
class AppDatabase extends _$AppDatabase {
  AppDatabase([QueryExecutor? e]) : super(e ?? _openConnection());

  @override
  int get schemaVersion => 2;

  @override
  MigrationStrategy get migration {
    return MigrationStrategy(
      onCreate: (Migrator m) async {
        await m.createAll();
        // Seed initial default financial categories, accounts and settings
        await _seedDefaults();
      },
      onUpgrade: (Migrator m, int from, int to) async {
        if (from < 2) {
          await m.createTable(accountsTable);
          await m.createTable(partiesTable);
          await m.createTable(journalEntriesTable);
          await m.createTable(postingsTable);
          await m.createTable(debtsTable);
          await m.createTable(settlementAllocationsTable);
        }
      },
      beforeOpen: (details) async {
        // Enforce foreign key constraints in SQLite
        await customStatement('PRAGMA foreign_keys = ON');
      },
    );
  }

  Future<void> _seedDefaults() async {
    const uuid = Uuid();
    final now = DateTime.now().toUtc();

    // Default settings
    await into(appSettings).insert(
      AppSettingsCompanion.insert(
        key: 'calendar_display_mode',
        value: 'dual', // dual, ethiopian_first, gregorian_first
        updatedAt: now,
      ),
    );
    await into(appSettings).insert(
      AppSettingsCompanion.insert(
        key: 'default_currency',
        value: 'ETB',
        updatedAt: now,
      ),
    );

    // Initial default categories for Ethiopian personal budgeting
    final defaultCategories = [
      {'name': 'ደመወዝ (Salary)', 'type': 'income', 'color': '#2E7D32'},
      {'name': 'ንግድ/ትርፍ (Business)', 'type': 'income', 'color': '#388E3C'},
      {'name': 'ምግብና ሸቀጣ ሸቀጥ (Groceries)', 'type': 'expense', 'color': '#E53935'},
      {'name': 'ቤት ኪራይ (Rent)', 'type': 'expense', 'color': '#D81B60'},
      {'name': 'ትራንስፖርት (Transport)', 'type': 'expense', 'color': '#FB8C00'},
      {'name': 'መብራትና ውኃ (Utilities)', 'type': 'expense', 'color': '#039BE5'},
      {'name': 'ጤና (Healthcare)', 'type': 'expense', 'color': '#8E24AA'},
      {'name': 'ቁጠባ (Savings Allocation)', 'type': 'expense', 'color': '#00897B'},
    ];

    for (final cat in defaultCategories) {
      await into(financialCategories).insert(
        FinancialCategoriesCompanion.insert(
          id: uuid.v4(),
          name: cat['name']!,
          type: cat['type']!,
          colorHex: Value(cat['color']!),
          isDefault: const Value(true),
        ),
      );
    }
  }

  // Schema Indices creation via custom statements if needed
  Future<void> createPerformanceIndices() async {
    await customStatement('CREATE INDEX IF NOT EXISTS idx_tasks_due_date ON tasks(due_date);');
    await customStatement('CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);');
    await customStatement('CREATE INDEX IF NOT EXISTS idx_transactions_date ON financial_transactions(transaction_date);');
    await customStatement('CREATE INDEX IF NOT EXISTS idx_inbox_processed ON inbox_items(is_processed);');
  }
}

LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    final dbFolder = await getApplicationDocumentsDirectory();
    final file = File(p.join(dbFolder.path, 'personal_management.sqlite'));
    return NativeDatabase.createInBackground(file);
  });
}
