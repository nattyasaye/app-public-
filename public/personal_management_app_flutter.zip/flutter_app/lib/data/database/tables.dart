import 'package:drift/drift.dart';

/// Quick Capture Inbox Entity
class InboxItems extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get rawText => text()();
  TextColumn get category => text().withDefault(const Constant('general'))(); // task, idea, expense, note, general
  BoolColumn get isProcessed => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Goals Table (High-level ambition)
class Goals extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get title => text().withLength(min: 1, max: 200)();
  TextColumn get description => text().nullable()();
  DateTimeColumn get targetDate => dateTime().nullable()();
  TextColumn get status => text().withDefault(const Constant('active'))(); // active, achieved, archived
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Projects Table (Organized work towards an outcome)
class Projects extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get goalId => text().nullable().references(Goals, #id, onDelete: KeyAction.setNull)();
  TextColumn get title => text().withLength(min: 1, max: 200)();
  TextColumn get description => text().nullable()();
  TextColumn get status => text().withDefault(const Constant('active'))(); // active, completed, on_hold
  DateTimeColumn get targetDate => dateTime().nullable()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Optional intermediate project milestones
class Milestones extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get projectId => text().references(Projects, #id, onDelete: KeyAction.cascade)();
  TextColumn get title => text().withLength(min: 1, max: 200)();
  DateTimeColumn get dueDate => dateTime().nullable()();
  BoolColumn get isCompleted => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Task items with priority, status, and project associations
class Tasks extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get title => text().withLength(min: 1, max: 300)();
  TextColumn get description => text().nullable()();
  TextColumn get status => text().withDefault(const Constant('inbox'))(); // inbox, not_started, in_progress, completed, cancelled
  TextColumn get priority => text().withDefault(const Constant('medium'))(); // low, medium, high, urgent
  DateTimeColumn get dueDate => dateTime().nullable()();
  DateTimeColumn get scheduledDate => dateTime().nullable()();
  IntColumn get estimatedDurationMinutes => integer().nullable()();
  TextColumn get projectId => text().nullable().references(Projects, #id, onDelete: KeyAction.setNull)();
  TextColumn get milestoneId => text().nullable().references(Milestones, #id, onDelete: KeyAction.setNull)();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Notes and Personal Information
class Notes extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get title => text().withLength(min: 1, max: 250)();
  TextColumn get content => text()(); // Full Unicode support for Amharic / Ge'ez
  TextColumn get category => text().withDefault(const Constant('general'))(); // general, reference, reflection, learning
  TextColumn get projectId => text().nullable().references(Projects, #id, onDelete: KeyAction.setNull)();
  TextColumn get goalId => text().nullable().references(Goals, #id, onDelete: KeyAction.setNull)();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Financial Categories
class FinancialCategories extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get name => text().withLength(min: 1, max: 100)();
  TextColumn get type => text()(); // income, expense
  TextColumn get colorHex => text().withDefault(const Constant('#4CAF50'))();
  BoolColumn get isDefault => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {id};
}

/// Recorded Financial Transactions (Integer minor units - cents)
class FinancialTransactions extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get categoryId => text().references(FinancialCategories, #id)();
  IntColumn get amountCents => integer()(); // Minor units in cents (1 ETB = 100 cents)
  TextColumn get type => text()(); // income, expense
  DateTimeColumn get transactionDate => dateTime()(); // Canonical UTC timestamp
  TextColumn get note => text().nullable()();
  TextColumn get payee => text().nullable()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Upcoming Financial Commitments (Bills, Rent, Subscriptions)
class FinancialCommitments extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get title => text().withLength(min: 1, max: 200)();
  IntColumn get amountCents => integer()(); // Minor units
  DateTimeColumn get dueDate => dateTime()();
  BoolColumn get isPaid => boolean().withDefault(const Constant(false))();
  TextColumn get recurringRule => text().nullable()(); // monthly, weekly, none
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Savings Goals & Allocations
class SavingsGoals extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get title => text().withLength(min: 1, max: 200)();
  IntColumn get targetCents => integer()();
  IntColumn get currentAllocatedCents => integer().withDefault(const Constant(0))();
  DateTimeColumn get targetDate => dateTime().nullable()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Local Reminders for Tasks and Commitments
class Reminders extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get targetId => text()(); // Task ID or Commitment ID
  TextColumn get targetType => text()(); // task, commitment, custom
  DateTimeColumn get triggerTimeUtc => dateTime()();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Key-Value Application Settings
class AppSettings extends Table {
  TextColumn get key => text()(); // e.g., 'calendar_preference', 'default_currency'
  TextColumn get value => text()();
  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column> get primaryKey => {key};
}

// ============================================================================
// REVISED DOUBLE-ENTRY ACCOUNTING TABLES (BALANCED LEDGER GUARANTEE)
// ============================================================================

/// Flexible Accounts (Strict single currency per account, ETB default)
class AccountsTable extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get name => text().withLength(min: 1, max: 150)();
  TextColumn get type => text()(); // asset, liability, equity, income, expense
  TextColumn get currencyCode => text().withDefault(const Constant('ETB'))();
  BoolColumn get isArchived => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Parties (Lenders, Borrowers, Colleagues, Creditors)
class PartiesTable extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get name => text().withLength(min: 1, max: 150)();
  TextColumn get phone => text().nullable()();
  TextColumn get notes => text().nullable()();
  BoolColumn get isArchived => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Journal Entries (Atomic business transaction headers)
class JournalEntriesTable extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get entryType => text()(); // standard, transfer, debt_issuance, settlement, split_expense, adjustment, write_off
  TextColumn get description => text()();
  TextColumn get occurrenceDate => text()(); // ISO Date YYYY-MM-DD (Economic date)
  BoolColumn get isVoided => boolean().withDefault(const Constant(false))();
  TextColumn get voidReason => text().nullable()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Postings (Debits and credits belonging to a journal entry)
/// Invariant: Sum of Debits == Sum of Credits per entry
class PostingsTable extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get entryId => text().references(JournalEntriesTable, #id, onDelete: KeyAction.cascade)();
  TextColumn get accountId => text().references(AccountsTable, #id)();
  IntColumn get amountCents => integer()(); // Minor units > 0
  TextColumn get direction => text()(); // 'debit' or 'credit'
  TextColumn get accountMovementDate => text()(); // ISO Date YYYY-MM-DD (Cash movement date)
  TextColumn get categoryId => text().nullable().references(FinancialCategories, #id)();
  TextColumn get note => text().nullable()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Debts (Receivables owed to me & Payables I owe to others)
class DebtsTable extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get originEntryId => text().references(JournalEntriesTable, #id)();
  TextColumn get partyId => text().references(PartiesTable, #id)();
  TextColumn get debtType => text()(); // 'receivable' | 'payable'
  IntColumn get principalCents => integer()(); // Minor units > 0
  IntColumn get outstandingCents => integer()(); // Remaining balance
  TextColumn get dueDate => text().nullable()(); // ISO Date YYYY-MM-DD
  TextColumn get status => text().withDefault(const Constant('active'))(); // active, settled, written_off
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Settlement Allocations (Links settlement journal entry to debt record)
class SettlementAllocationsTable extends Table {
  TextColumn get id => text()(); // UUID v4
  TextColumn get settlementEntryId => text().references(JournalEntriesTable, #id)();
  TextColumn get debtId => text().references(DebtsTable, #id)();
  IntColumn get allocatedCents => integer()(); // Amount applied to reduce principal
  TextColumn get settlementDate => text()(); // ISO Date YYYY-MM-DD

  @override
  Set<Column> get primaryKey => {id};
}

