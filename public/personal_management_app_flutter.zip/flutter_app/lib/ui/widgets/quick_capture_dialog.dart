import 'package:flutter/material.dart';
import '../app_state.dart';

class QuickCaptureDialog extends StatefulWidget {
  final AppStateManager state;
  final String? initialText;

  const QuickCaptureDialog({
    super.key,
    required this.state,
    this.initialText,
  });

  @override
  State<QuickCaptureDialog> createState() => _QuickCaptureDialogState();
}

class _QuickCaptureDialogState extends State<QuickCaptureDialog> {
  late TextEditingController _controller;
  String _category = 'task';

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialText ?? '');
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _save() {
    final text = _controller.text.trim();
    if (text.isNotEmpty) {
      widget.state.addInboxItem(text, _category);
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Captured into Inbox & ${_category.toUpperCase()}!'),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.flash_on_rounded, color: Color(0xFF1B5E20)),
                const SizedBox(width: 8),
                const Text(
                  '1-Tap Quick Capture (<3s)',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _controller,
              autofocus: true,
              decoration: const InputDecoration(
                hintText: 'What is on your mind? (Idea, task, expense...)',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 12),
            const Text('Save as:', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              children: [
                ChoiceChip(
                  label: const Text('Task'),
                  selected: _category == 'task',
                  onSelected: (sel) => setState(() => _category = 'task'),
                ),
                ChoiceChip(
                  label: const Text('Expense'),
                  selected: _category == 'expense',
                  onSelected: (sel) => setState(() => _category = 'expense'),
                ),
                ChoiceChip(
                  label: const Text('Note'),
                  selected: _category == 'note',
                  onSelected: (sel) => setState(() => _category = 'note'),
                ),
                ChoiceChip(
                  label: const Text('Idea'),
                  selected: _category == 'idea',
                  onSelected: (sel) => setState(() => _category = 'idea'),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: _save,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1B5E20),
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Capture'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
