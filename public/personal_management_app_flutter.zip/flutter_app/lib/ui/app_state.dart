import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../domain/calendar/ethiopian_calendar.dart';
import '../domain/finance/financial_engine.dart';
import '../domain/finance/double_entry_engine.dart';
import '../domain/projects/progress_engine.dart';
import '../services/backup/encryption_backup_service.dart';
import '../services/export/finance_export_service.dart';

/// Models for in-memory & SQLite-backed application state
class TaskModel {
  final String id;
  final String title;
  final String? description;
  final String status; // 'not_started', 'in_progress', 'completed', 'cancelled'
  final String priority; // 'low', 'medium', 'high', 'urgent'
  final DateTime? dueDate;
  final String? projectId;
  final DateTime createdAt;

  TaskModel({
    required this.id,
    required this.title,
    this.description,
    this.status = 'not_started',
    this.priority = 'medium',
    this.dueDate,
    this.projectId,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now().toUtc();

  TaskModel copyWith({
    String? title,
    String? description,
    String? status,
    String? priority,
    DateTime? dueDate,
    String? projectId,
  }) {
    return TaskModel(
      id: id,
      title: title ?? this.title,
      description: description ?? this.description,
      status: status ?? this.status,
      priority: priority ?? this.priority,
      dueDate: dueDate ?? this.dueDate,
      projectId: projectId ?? this.projectId,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'description': description,
    'status': status,
    'priority': priority,
    'dueDate': dueDate?.toIso8601String(),
    'projectId': projectId,
    'createdAt': createdAt.toIso8601String(),
  };

  factory TaskModel.fromJson(Map<String, dynamic> json) => TaskModel(
    id: json['id'],
    title: json['title'],
    description: json['description'],
    status: json['status'] ?? 'not_started',
    priority: json['priority'] ?? 'medium',
    dueDate: json['dueDate'] != null ? DateTime.tryParse(json['dueDate']) : null,
    projectId: json['projectId'],
    createdAt: json['createdAt'] != null ? DateTime.tryParse(json['createdAt']) : null,
  );
}

class ProjectModel {
  final String id;
  final String title;
  final String? description;
  final String status; // 'active', 'completed', 'on_hold'
  final DateTime? targetDate;
  final DateTime createdAt;

  ProjectModel({
    required this.id,
    required this.title,
    this.description,
    this.status = 'active',
    this.targetDate,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now().toUtc();

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'description': description,
    'status': status,
    'targetDate': targetDate?.toIso8601String(),
    'createdAt': createdAt.toIso8601String(),
  };

  factory ProjectModel.fromJson(Map<String, dynamic> json) => ProjectModel(
    id: json['id'],
    title: json['title'],
    description: json['description'],
    status: json['status'] ?? 'active',
    targetDate: json['targetDate'] != null ? DateTime.tryParse(json['targetDate']) : null,
    createdAt: json['createdAt'] != null ? DateTime.tryParse(json['createdAt']) : null,
  );
}

class TransactionModel {
  final String id;
  final String categoryId;
  final String categoryName;
  final int amountCents;
  final String type; // 'income', 'expense'
  final DateTime transactionDate;
  final String? note;
  final String? payee;
  final bool isSuperseded;
  final String? correctedFromId;
  final String? correctionReason;

  TransactionModel({
    required this.id,
    required this.categoryId,
    required this.categoryName,
    required this.amountCents,
    required this.type,
    required this.transactionDate,
    this.note,
    this.payee,
    this.isSuperseded = false,
    this.correctedFromId,
    this.correctionReason,
  });

  TransactionModel copyWith({
    bool? isSuperseded,
    String? note,
  }) {
    return TransactionModel(
      id: id,
      categoryId: categoryId,
      categoryName: categoryName,
      amountCents: amountCents,
      type: type,
      transactionDate: transactionDate,
      note: note ?? this.note,
      payee: payee,
      isSuperseded: isSuperseded ?? this.isSuperseded,
      correctedFromId: correctedFromId,
      correctionReason: correctionReason,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'categoryId': categoryId,
    'categoryName': categoryName,
    'amountCents': amountCents,
    'type': type,
    'transactionDate': transactionDate.toIso8601String(),
    'note': note,
    'payee': payee,
    'isSuperseded': isSuperseded,
    'correctedFromId': correctedFromId,
    'correctionReason': correctionReason,
  };

  factory TransactionModel.fromJson(Map<String, dynamic> json) => TransactionModel(
    id: json['id'],
    categoryId: json['categoryId'] ?? 'cat-1',
    categoryName: json['categoryName'] ?? 'General',
    amountCents: json['amountCents'] ?? 0,
    type: json['type'] ?? 'expense',
    transactionDate: json['transactionDate'] != null
        ? DateTime.parse(json['transactionDate'])
        : DateTime.now(),
    note: json['note'],
    payee: json['payee'],
    isSuperseded: json['isSuperseded'] ?? false,
    correctedFromId: json['correctedFromId'],
    correctionReason: json['correctionReason'],
  );
}

class CommitmentModel {
  final String id;
  final String title;
  final int amountCents;
  final DateTime dueDate;
  final bool isPaid;
  final String? recurringRule;

  CommitmentModel({
    required this.id,
    required this.title,
    required this.amountCents,
    required this.dueDate,
    this.isPaid = false,
    this.recurringRule = 'monthly',
  });

  CommitmentModel copyWith({bool? isPaid}) {
    return CommitmentModel(
      id: id,
      title: title,
      amountCents: amountCents,
      dueDate: dueDate,
      isPaid: isPaid ?? this.isPaid,
      recurringRule: recurringRule,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'amountCents': amountCents,
    'dueDate': dueDate.toIso8601String(),
    'isPaid': isPaid,
    'recurringRule': recurringRule,
  };

  factory CommitmentModel.fromJson(Map<String, dynamic> json) => CommitmentModel(
    id: json['id'],
    title: json['title'],
    amountCents: json['amountCents'] ?? 0,
    dueDate: json['dueDate'] != null ? DateTime.parse(json['dueDate']) : DateTime.now(),
    isPaid: json['isPaid'] ?? false,
    recurringRule: json['recurringRule'],
  );
}

class SavingsGoalModel {
  final String id;
  final String title;
  final int targetCents;
  final int currentAllocatedCents;
  final DateTime? targetDate;

  SavingsGoalModel({
    required this.id,
    required this.title,
    required this.targetCents,
    this.currentAllocatedCents = 0,
    this.targetDate,
  });

  SavingsGoalModel copyWith({int? currentAllocatedCents}) {
    return SavingsGoalModel(
      id: id,
      title: title,
      targetCents: targetCents,
      currentAllocatedCents: currentAllocatedCents ?? this.currentAllocatedCents,
      targetDate: targetDate,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'targetCents': targetCents,
    'currentAllocatedCents': currentAllocatedCents,
    'targetDate': targetDate?.toIso8601String(),
  };

  factory SavingsGoalModel.fromJson(Map<String, dynamic> json) => SavingsGoalModel(
    id: json['id'],
    title: json['title'],
    targetCents: json['targetCents'] ?? 0,
    currentAllocatedCents: json['currentAllocatedCents'] ?? 0,
    targetDate: json['targetDate'] != null ? DateTime.tryParse(json['targetDate']) : null,
  );
}

class NoteModel {
  final String id;
  final String title;
  final String content;
  final String category; // 'reflection', 'reference', 'learning', 'general'
  final String? projectId;
  final DateTime createdAt;

  NoteModel({
    required this.id,
    required this.title,
    required this.content,
    this.category = 'general',
    this.projectId,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now().toUtc();

  NoteModel copyWith({
    String? title,
    String? content,
    String? category,
    String? projectId,
  }) {
    return NoteModel(
      id: id,
      title: title ?? this.title,
      content: content ?? this.content,
      category: category ?? this.category,
      projectId: projectId ?? this.projectId,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'content': content,
    'category': category,
    'projectId': projectId,
    'createdAt': createdAt.toIso8601String(),
  };

  factory NoteModel.fromJson(Map<String, dynamic> json) => NoteModel(
    id: json['id'],
    title: json['title'],
    content: json['content'] ?? '',
    category: json['category'] ?? 'general',
    projectId: json['projectId'],
    createdAt: json['createdAt'] != null ? DateTime.tryParse(json['createdAt']) : null,
  );
}

class InboxItemModel {
  final String id;
  final String rawText;
  final String category;
  final bool isProcessed;
  final DateTime createdAt;

  InboxItemModel({
    required this.id,
    required this.rawText,
    this.category = 'general',
    this.isProcessed = false,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now().toUtc();

  Map<String, dynamic> toJson() => {
    'id': id,
    'rawText': rawText,
    'category': category,
    'isProcessed': isProcessed,
    'createdAt': createdAt.toIso8601String(),
  };

  factory InboxItemModel.fromJson(Map<String, dynamic> json) => InboxItemModel(
    id: json['id'],
    rawText: json['rawText'],
    category: json['category'] ?? 'general',
    isProcessed: json['isProcessed'] ?? false,
    createdAt: json['createdAt'] != null ? DateTime.tryParse(json['createdAt']) : null,
  );
}

/// Central state manager holding all entities and domain calculations
class AppStateManager extends ChangeNotifier {
  int openingBalanceCents = 1500000; // 15,000.00 ETB
  List<TaskModel> tasks = [];
  List<ProjectModel> projects = [];
  List<TransactionModel> transactions = [];
  List<CommitmentModel> commitments = [];
  List<SavingsGoalModel> savingsGoals = [];
  List<NoteModel> notes = [];
  List<InboxItemModel> inboxItems = [];

  // Double-Entry Ledger State
  List<AccountModel> accounts = [];
  List<PartyModel> parties = [];
  List<JournalEntryModel> journalEntries = [];
  List<PostingModel> postings = [];
  List<DebtModel> debts = [];
  List<SettlementAllocationModel> settlementAllocations = [];

  final EncryptionBackupService _backupService = EncryptionBackupService();

  AppStateManager() {
    _seedInitialData();
  }

  void _seedInitialData() {
    final now = DateTime.now();

    projects = [
      ProjectModel(
        id: 'proj-1',
        title: 'አዲስ ንግድ ማደራጀት (Launch New Enterprise)',
        description: 'Establish local consulting & logistics enterprise in Addis Ababa',
        targetDate: now.add(const Duration(days: 45)),
      ),
      ProjectModel(
        id: 'proj-2',
        title: 'የቋንቋና ቴክኖሎጂ ጥናት (Mobile & Tech Stack)',
        description: 'Master Flutter, Drift SQLite, and cryptography architecture',
        targetDate: now.add(const Duration(days: 20)),
      ),
    ];

    tasks = [
      TaskModel(
        id: 'task-1',
        title: 'የንግድ ምዝገባ ሰነድ ማዘጋጀት (Prepare Business Registration Docs)',
        description: 'Complete registration at trade bureau with identification',
        priority: 'urgent',
        status: 'not_started',
        dueDate: now.add(const Duration(days: 1)),
        projectId: 'proj-1',
      ),
      TaskModel(
        id: 'task-2',
        title: 'የወሩን የቤት ኪራይ ማጠናቀቅ (Pay House Rent)',
        description: 'Transfer 7,000 ETB rent via mobile banking',
        priority: 'high',
        status: 'in_progress',
        dueDate: now.add(const Duration(days: 2)),
      ),
      TaskModel(
        id: 'task-3',
        title: 'የሳምንታዊ ሸቀጥና ምግብ ግዢ (Weekly Grocery Shopping)',
        description: 'Vegetables, teff, oil, spices from local market',
        priority: 'medium',
        status: 'not_started',
        dueDate: now.add(const Duration(days: 3)),
      ),
      TaskModel(
        id: 'task-4',
        title: 'የመጠባበቂያ ዳታባክአፕ ማረጋገጥ (Verify Passphrase Backup)',
        description: 'Export encrypted .pmbackup to external flash drive',
        priority: 'low',
        status: 'completed',
        dueDate: now.subtract(const Duration(days: 1)),
      ),
    ];

    transactions = [
      TransactionModel(
        id: 'tx-1',
        categoryId: 'cat-salary',
        categoryName: 'ደመወዝ (Salary)',
        amountCents: 4500000, // 45,000.00 ETB
        type: 'income',
        transactionDate: now.subtract(const Duration(days: 5)),
        payee: 'Employer / Main Client',
        note: 'Monthly salary compensation deposited',
      ),
      TransactionModel(
        id: 'tx-2',
        categoryId: 'cat-rent',
        categoryName: 'ቤት ኪራይ (Rent)',
        amountCents: 850000, // 8,500.00 ETB
        type: 'expense',
        transactionDate: now.subtract(const Duration(days: 3)),
        payee: 'Landlord',
        note: 'Apartment monthly rent paid',
      ),
      TransactionModel(
        id: 'tx-3',
        categoryId: 'cat-groceries',
        categoryName: 'ምግብና ሸቀጣ ሸቀጥ (Groceries)',
        amountCents: 245050, // 2,450.50 ETB
        type: 'expense',
        transactionDate: now.subtract(const Duration(days: 1)),
        payee: 'Mercato Central Store',
        note: 'Teff, coffee, and household supplies',
      ),
    ];

    commitments = [
      CommitmentModel(
        id: 'com-1',
        title: 'የቤት ኪራይ (House Rent - Upcoming)',
        amountCents: 850000, // 8,500.00 ETB
        dueDate: now.add(const Duration(days: 12)),
        isPaid: false,
      ),
      CommitmentModel(
        id: 'com-2',
        title: 'የኢንተርኔትና መብራት ክፍያ (WiFi & Electric Utility)',
        amountCents: 150000, // 1,500.00 ETB
        dueDate: now.add(const Duration(days: 7)),
        isPaid: false,
      ),
    ];

    savingsGoals = [
      SavingsGoalModel(
        id: 'sav-1',
        title: 'የአደጋ ጊዜ መጠባበቂያ ፈንድ (Emergency Fund)',
        targetCents: 5000000, // 50,000.00 ETB
        currentAllocatedCents: 1800000, // 18,000.00 ETB
      ),
      SavingsGoalModel(
        id: 'sav-2',
        title: 'የአዲስ ላፕቶፕ ቁጠባ (Work Laptop Upgrade)',
        targetCents: 8000000, // 80,000.00 ETB
        currentAllocatedCents: 2500000, // 25,000.00 ETB
      ),
    ];

    notes = [
      NoteModel(
        id: 'note-1',
        title: 'የዓመት ዕቅድና የሕይወት ግቦች (Life Vision & Reflections)',
        content: 'ትኩረት ማድረግ ያለብኝ ዋና ጉዳዮች፡- ጤና፣ የገንዘብ ነፃነት፣ እና የቴክኖሎጂ ክህሎትን ማሳደግ። በየቀኑ ጠዋት የዕለቱን 3 ዋና ተግባራት መለየት።',
        category: 'reflection',
        projectId: 'proj-1',
      ),
      NoteModel(
        id: 'note-2',
        title: 'Drift SQLite Database Architecture Notes',
        content: 'Local SQLite tables store all minor-unit ETB cents as integers. Backups use AES-GCM-256 with PBKDF2 100,000 iterations for bulletproof privacy.',
        category: 'reference',
        projectId: 'proj-2',
      ),
    ];

    inboxItems = [
      InboxItemModel(
        id: 'inbox-1',
        rawText: 'Call mechanic regarding vehicle brake inspection',
        category: 'task',
      ),
    ];

    // Seed Double-Entry Accounts (Full Ethiopian banking & cash suite)
    accounts = [
      AccountModel(id: 'acc-cbe', name: 'CBE (Commercial Bank of Ethiopia)', type: AccountType.asset),
      AccountModel(id: 'acc-boa', name: 'BOA (Bank of Abyssinia)', type: AccountType.asset),
      AccountModel(id: 'acc-dashen', name: 'Dashen Bank (ዳሽን ባንክ)', type: AccountType.asset),
      AccountModel(id: 'acc-telebirr', name: 'Telebirr (ቴሌብር)', type: AccountType.asset),
      AccountModel(id: 'acc-cash', name: 'Cash Wallet (ጥሬ ገንዘብ)', type: AccountType.asset),
      AccountModel(id: 'acc-rec', name: 'Accounts Receivable (ተሰብሳቢ ሒሳብ)', type: AccountType.asset),
      AccountModel(id: 'acc-pay', name: 'Accounts Payable (ተከፋይ ዕዳ)', type: AccountType.liability),
      AccountModel(id: 'acc-inc-salary', name: 'Income: Salary (ደመወዝ)', type: AccountType.income),
      AccountModel(id: 'acc-inc-interest', name: 'Income: Interest (ወለድ)', type: AccountType.income),
      AccountModel(id: 'acc-exp-groceries', name: 'Expense: Food & Groceries (ምግብና ሸቀጥ)', type: AccountType.expense),
      AccountModel(id: 'acc-exp-rent', name: 'Expense: Rent (ቤት ኪራይ)', type: AccountType.expense),
      AccountModel(id: 'acc-exp-dining', name: 'Expense: Dining (ምግብ ቤት)', type: AccountType.expense),
      AccountModel(id: 'acc-exp-fees', name: 'Expense: Bank & Transfer Fees (የባንክ አገልግሎት ክፍያ)', type: AccountType.expense),
    ];

    // Seed Parties
    parties = [
      PartyModel(id: 'party-abebe', name: 'Abebe Kebede (አበበ ከበደ)', phone: '+251911223344'),
      PartyModel(id: 'party-landlord', name: 'Landlord Ato Tadesse (አቶ ታደሰ)', phone: '+251912345678'),
      PartyModel(id: 'party-boss', name: 'Office Boss / Client (አለቃ / ደንበኛ)'),
    ];

    // Seed Journal Entries & Postings (Example A, B, C, D)
    final salaryEntry = JournalEntryModel(
      id: 'entry-seed-salary',
      entryType: EntryType.standard,
      description: 'Monthly Salary Deposit (የወር ደመወዝ ገቢ)',
      occurrenceDate: '2026-11-01',
    );
    journalEntries.add(salaryEntry);
    postings.addAll([
      PostingModel(id: 'p-sal-dr', entryId: salaryEntry.id, accountId: 'acc-cbe', amountCents: 4500000, direction: PostingDirection.debit, accountMovementDate: '2026-11-01'),
      PostingModel(id: 'p-sal-cr', entryId: salaryEntry.id, accountId: 'acc-inc-salary', amountCents: 4500000, direction: PostingDirection.credit, accountMovementDate: '2026-11-01'),
    ]);

    // Example B: Lent 1,000 ETB cash to Abebe
    final lendResult = DoubleEntryEngine.buildLendMoney(
      entryId: 'entry-seed-lend',
      debtId: 'debt-seed-lend-1',
      partyId: 'party-abebe',
      receivableAccountId: 'acc-rec',
      sourceAssetAccountId: 'acc-cash',
      amountCents: 100000, // 1,000 ETB
      date: '2026-11-03',
      dueDate: '2026-11-20',
      description: 'Lent money to Abebe (ለአበበ የተሰጠ ብድር)',
    );
    journalEntries.add(lendResult['entry'] as JournalEntryModel);
    postings.addAll(lendResult['postings'] as List<PostingModel>);
    debts.add(lendResult['debt'] as DebtModel);

    // Example C: Borrowed 2,000 ETB into Telebirr from Landlord
    final borrowResult = DoubleEntryEngine.buildBorrowMoney(
      entryId: 'entry-seed-borrow',
      debtId: 'debt-seed-borrow-1',
      partyId: 'party-landlord',
      destAssetAccountId: 'acc-telebirr',
      payableAccountId: 'acc-pay',
      amountCents: 200000, // 2,000 ETB
      date: '2026-11-04',
      dueDate: '2026-11-25',
      description: 'Borrowed from Landlord (ከአከራይ የተበደረ)',
    );
    journalEntries.add(borrowResult['entry'] as JournalEntryModel);
    postings.addAll(borrowResult['postings'] as List<PostingModel>);
    debts.add(borrowResult['debt'] as DebtModel);

    // Partial Repayment of Borrowed Debt (500 ETB repaid)
    final settleBorrowResult = DoubleEntryEngine.buildDebtSettlement(
      settlementEntryId: 'entry-seed-settle-borrow',
      debt: debts.last,
      settlementAssetAccountId: 'acc-telebirr',
      debtAccountId: 'acc-pay',
      allocatedPrincipalCents: 50000,
      settlementDate: '2026-11-06',
      description: 'Partial Repayment to Landlord (የብድር ከፊል ክፍያ)',
    );
    journalEntries.add(settleBorrowResult['entry'] as JournalEntryModel);
    postings.addAll(settleBorrowResult['postings'] as List<PostingModel>);
    settlementAllocations.add(settleBorrowResult['allocation'] as SettlementAllocationModel);
    debts[debts.length - 1] = settleBorrowResult['updatedDebt'] as DebtModel;

    // Example D: Split Dinner Bill (Total 1,000 ETB, My share 400 ETB, Abebe owes 600 ETB)
    final splitResult = DoubleEntryEngine.buildSplitExpense(
      entryId: 'entry-seed-split',
      debtId: 'debt-seed-split-1',
      partyId: 'party-abebe',
      myExpenseAccountId: 'acc-exp-dining',
      receivableAccountId: 'acc-rec',
      paidAssetAccountId: 'acc-cbe',
      myShareCents: 40000,
      theirShareCents: 60000,
      occurrenceDate: '2026-11-07',
      description: 'Restaurant dinner split with Abebe (የእራት ክፍያ ድርሻ)',
    );
    journalEntries.add(splitResult['entry'] as JournalEntryModel);
    postings.addAll(splitResult['postings'] as List<PostingModel>);
    debts.add(splitResult['debt'] as DebtModel);
  }


  // --- Financial Snapshot ---
  FinancialSnapshot get financialSnapshot {
    final activeTx = transactions.where((t) => !t.isSuperseded).toList();
    final incomeCents = activeTx.where((t) => t.type == 'income').map((t) => t.amountCents).toList();
    final expenseCents = activeTx.where((t) => t.type == 'expense').map((t) => t.amountCents).toList();

    final unpaidCommitmentsCents = commitments.where((c) => !c.isPaid).map((c) => c.amountCents).toList();
    final savingsAllocationsCents = savingsGoals.map((s) => s.currentAllocatedCents).toList();

    return FinancialEngine.computeSnapshot(
      openingBalanceCents: openingBalanceCents,
      receivedIncomeCents: incomeCents,
      recordedExpenseCents: expenseCents,
      unpaidCommitmentsInPeriodCents: unpaidCommitmentsCents,
      savingsAllocationsInPeriodCents: savingsAllocationsCents,
      expectedFutureIncomeCents: [],
    );
  }

  // --- Double-Entry Financial Metrics ---
  int get liquidCashCents => DoubleEntryEngine.calculateLiquidCash(
        accounts: accounts,
        postings: postings,
        entries: journalEntries,
      );

  int get netFinancialPositionCents => DoubleEntryEngine.calculateNetPosition(
        accounts: accounts,
        postings: postings,
        entries: journalEntries,
      );

  int get totalReceivablesCents {
    return debts
        .where((d) => d.debtType == DebtType.receivable && d.status == DebtStatus.active)
        .fold<int>(0, (sum, d) => sum + d.outstandingCents);
  }

  int get totalPayablesCents {
    return debts
        .where((d) => d.debtType == DebtType.payable && d.status == DebtStatus.active)
        .fold<int>(0, (sum, d) => sum + d.outstandingCents);
  }

  int get availableToSpendCents {
    final reservedSavings = savingsGoals.fold<int>(0, (sum, s) => sum + s.currentAllocatedCents);
    return DoubleEntryEngine.calculateAvailableToSpend(
      liquidCashCents: liquidCashCents,
      unpaidPayablesDueInPeriodCents: totalPayablesCents,
      reservedSavingsCents: reservedSavings,
    );
  }

  // --- Account Management Methods ---
  void addAccount({
    required String name,
    required AccountType type,
    String currencyCode = 'ETB',
    int openingBalanceCents = 0,
    String? equityAccountId,
  }) {
    final accId = 'acc-${DateTime.now().millisecondsSinceEpoch}';
    final newAccount = AccountModel(
      id: accId,
      name: name,
      type: type,
      currencyCode: currencyCode,
    );
    accounts.add(newAccount);

    if (openingBalanceCents > 0) {
      final entryId = 'entry-open-${DateTime.now().millisecondsSinceEpoch}';
      final openEntry = JournalEntryModel(
        id: entryId,
        entryType: EntryType.adjustment,
        description: 'Opening Balance for $name',
        occurrenceDate: DateTime.now().toIso8601String().substring(0, 10),
      );
      final pDr = PostingModel(
        id: '$entryId-dr',
        entryId: entryId,
        accountId: accId,
        amountCents: openingBalanceCents,
        direction: PostingDirection.debit,
        accountMovementDate: DateTime.now().toIso8601String().substring(0, 10),
        note: 'Initial opening balance',
      );
      // Credit equity/opening balance account
      final eqId = equityAccountId ?? 'acc-inc-salary';
      final pCr = PostingModel(
        id: '$entryId-cr',
        entryId: entryId,
        accountId: eqId,
        amountCents: openingBalanceCents,
        direction: PostingDirection.credit,
        accountMovementDate: DateTime.now().toIso8601String().substring(0, 10),
        note: 'Opening balance offset',
      );
      DoubleEntryEngine.validateBalancedEntry([pDr, pCr]);
      journalEntries.insert(0, openEntry);
      postings.addAll([pDr, pCr]);
    }
    notifyListeners();
  }

  void archiveAccount(String accountId) {
    final idx = accounts.indexWhere((a) => a.id == accountId);
    if (idx != -1) {
      accounts[idx] = accounts[idx].copyWith(isArchived: true);
      notifyListeners();
    }
  }

  /// Ensure a contact/party exists by name, or create it dynamically on the fly
  String ensurePartyId(String name, {String? phone}) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return 'party-abebe';
    final match = parties.where((p) => p.name.toLowerCase() == trimmed.toLowerCase());
    if (match.isNotEmpty) return match.first.id;

    final newId = 'party-${DateTime.now().millisecondsSinceEpoch}';
    final newParty = PartyModel(
      id: newId,
      name: trimmed,
      phone: phone,
      createdAt: DateTime.now().toUtc(),
    );
    parties.add(newParty);
    notifyListeners();
    return newId;
  }

  // --- Transfer with Fee Method ---
  void recordAccountTransfer({
    required String fromAssetAccountId,
    required String toAssetAccountId,
    required int amountCents,
    required String date,
    required String description,
    int transferFeeCents = 0,
    String? feeExpenseAccountId,
    String? note,
  }) {
    final entryId = 'entry-xfer-${DateTime.now().millisecondsSinceEpoch}';
    final res = DoubleEntryEngine.buildTransfer(
      entryId: entryId,
      fromAssetAccountId: fromAssetAccountId,
      toAssetAccountId: toAssetAccountId,
      amountCents: amountCents,
      date: date,
      description: description,
      transferFeeCents: transferFeeCents,
      feeExpenseAccountId: feeExpenseAccountId ?? 'acc-exp-fees',
      note: note,
    );
    journalEntries.insert(0, res['entry'] as JournalEntryModel);
    postings.addAll(res['postings'] as List<PostingModel>);
    notifyListeners();
  }

  // --- Void / Reversal Method ---
  void voidJournalEntry(String entryId, String reason) {
    final idx = journalEntries.indexWhere((e) => e.id == entryId);
    if (idx != -1) {
      final entry = journalEntries[idx];
      journalEntries[idx] = DoubleEntryEngine.buildVoidEntry(entry: entry, reason: reason);
      notifyListeners();
    }
  }

  void addDoubleEntryDirectExpense({
    required String assetAccountId,
    required String expenseAccountId,
    required int amountCents,
    required String description,
    required String occurrenceDate,
    String? categoryId,
  }) {
    final entryId = 'entry-${DateTime.now().millisecondsSinceEpoch}';
    final entry = JournalEntryModel(
      id: entryId,
      entryType: EntryType.standard,
      description: description,
      occurrenceDate: occurrenceDate,
    );
    final pDr = PostingModel(
      id: '$entryId-dr',
      entryId: entryId,
      accountId: expenseAccountId,
      amountCents: amountCents,
      direction: PostingDirection.debit,
      accountMovementDate: occurrenceDate,
      categoryId: categoryId,
    );
    final pCr = PostingModel(
      id: '$entryId-cr',
      entryId: entryId,
      accountId: assetAccountId,
      amountCents: amountCents,
      direction: PostingDirection.credit,
      accountMovementDate: occurrenceDate,
    );
    DoubleEntryEngine.validateBalancedEntry([pDr, pCr]);
    journalEntries.insert(0, entry);
    postings.addAll([pDr, pCr]);
    notifyListeners();
  }

  void addDoubleEntryThirdPartyPaid({
    required String partyId,
    required String expenseAccountId,
    required String payableAccountId,
    required int amountCents,
    required String occurrenceDate,
    required String description,
    String? dueDate,
  }) {
    final entryId = 'entry-${DateTime.now().millisecondsSinceEpoch}';
    final debtId = 'debt-${DateTime.now().millisecondsSinceEpoch}';
    final res = DoubleEntryEngine.buildThirdPartyPaidExpense(
      entryId: entryId,
      debtId: debtId,
      partyId: partyId,
      expenseAccountId: expenseAccountId,
      payableAccountId: payableAccountId,
      amountCents: amountCents,
      occurrenceDate: occurrenceDate,
      dueDate: dueDate,
      description: description,
    );
    journalEntries.insert(0, res['entry'] as JournalEntryModel);
    postings.addAll(res['postings'] as List<PostingModel>);
    debts.insert(0, res['debt'] as DebtModel);
    notifyListeners();
  }

  void addDoubleEntryLendMoney({
    required String partyId,
    required String sourceAssetAccountId,
    required int amountCents,
    required String date,
    required String description,
    String? dueDate,
  }) {
    final entryId = 'entry-${DateTime.now().millisecondsSinceEpoch}';
    final debtId = 'debt-${DateTime.now().millisecondsSinceEpoch}';
    final res = DoubleEntryEngine.buildLendMoney(
      entryId: entryId,
      debtId: debtId,
      partyId: partyId,
      receivableAccountId: 'acc-rec',
      sourceAssetAccountId: sourceAssetAccountId,
      amountCents: amountCents,
      date: date,
      dueDate: dueDate,
      description: description,
    );
    journalEntries.insert(0, res['entry'] as JournalEntryModel);
    postings.addAll(res['postings'] as List<PostingModel>);
    debts.insert(0, res['debt'] as DebtModel);
    notifyListeners();
  }

  void addDoubleEntryBorrowMoney({
    required String partyId,
    required String destAssetAccountId,
    required int amountCents,
    required String date,
    required String description,
    String? dueDate,
  }) {
    final entryId = 'entry-${DateTime.now().millisecondsSinceEpoch}';
    final debtId = 'debt-${DateTime.now().millisecondsSinceEpoch}';
    final res = DoubleEntryEngine.buildBorrowMoney(
      entryId: entryId,
      debtId: debtId,
      partyId: partyId,
      destAssetAccountId: destAssetAccountId,
      payableAccountId: 'acc-pay',
      amountCents: amountCents,
      date: date,
      dueDate: dueDate,
      description: description,
    );
    journalEntries.insert(0, res['entry'] as JournalEntryModel);
    postings.addAll(res['postings'] as List<PostingModel>);
    debts.insert(0, res['debt'] as DebtModel);
    notifyListeners();
  }

  void recordDoubleEntrySettlement({
    required DebtModel debt,
    required String settlementAssetAccountId,
    required int allocatedCents,
    int interestCents = 0,
    required String settlementDate,
    required String description,
  }) {
    final settlementEntryId = 'entry-${DateTime.now().millisecondsSinceEpoch}';
    final debtAccountId = debt.debtType == DebtType.payable ? 'acc-pay' : 'acc-rec';
    final res = DoubleEntryEngine.buildDebtSettlement(
      settlementEntryId: settlementEntryId,
      debt: debt,
      settlementAssetAccountId: settlementAssetAccountId,
      debtAccountId: debtAccountId,
      allocatedPrincipalCents: allocatedCents,
      interestCents: interestCents,
      interestAccountId: debt.debtType == DebtType.payable ? 'acc-exp-interest' : 'acc-inc-interest',
      settlementDate: settlementDate,
      description: description,
    );
    journalEntries.insert(0, res['entry'] as JournalEntryModel);
    postings.addAll(res['postings'] as List<PostingModel>);
    settlementAllocations.insert(0, res['allocation'] as SettlementAllocationModel);
    final idx = debts.indexWhere((d) => d.id == debt.id);
    if (idx != -1) {
      debts[idx] = res['updatedDebt'] as DebtModel;
    }
    notifyListeners();
  }


  // --- Task Methods ---
  void addTask(TaskModel task) {
    tasks.insert(0, task);
    notifyListeners();
  }

  void toggleTaskStatus(String id) {
    final idx = tasks.indexWhere((t) => t.id == id);
    if (idx != -1) {
      final current = tasks[idx];
      final newStatus = current.status == 'completed' ? 'not_started' : 'completed';
      tasks[idx] = current.copyWith(status: newStatus);
      notifyListeners();
    }
  }

  void deleteTask(String id) {
    tasks.removeWhere((t) => t.id == id);
    notifyListeners();
  }

  // --- Project Methods ---
  void addProject(ProjectModel project) {
    projects.add(project);
    notifyListeners();
  }

  int getProjectProgress(String projectId) {
    final projTasks = tasks.where((t) => t.projectId == projectId).toList();
    final completed = projTasks.where((t) => t.status == 'completed').length;
    return ProgressEngine.calculateProgressPercentage(
      totalTasks: projTasks.length,
      completedTasks: completed,
      totalMilestones: 0,
      completedMilestones: 0,
    );
  }

  // --- Financial Methods ---
  void recordTransaction(TransactionModel tx) {
    transactions.insert(0, tx);
    notifyListeners();
  }

  void correctTransaction({
    required String originalId,
    required int newAmountCents,
    required String newCategoryName,
    required String reason,
    String? newNote,
    String? newPayee,
  }) {
    final idx = transactions.indexWhere((t) => t.id == originalId);
    if (idx != -1) {
      final orig = transactions[idx];
      final newId = 'tx-${DateTime.now().millisecondsSinceEpoch}';

      // Insert correction
      final corrected = TransactionModel(
        id: newId,
        categoryId: orig.categoryId,
        categoryName: newCategoryName,
        amountCents: newAmountCents,
        type: orig.type,
        transactionDate: orig.transactionDate,
        note: '[Corrected from ${orig.id.substring(0, 6)}: $reason] ${newNote ?? orig.note ?? ''}',
        payee: newPayee ?? orig.payee,
        correctedFromId: orig.id,
        correctionReason: reason,
      );

      // Supersede original
      transactions[idx] = orig.copyWith(
        isSuperseded: true,
        note: '[Superseded by ${newId.substring(0, 6)}] ${orig.note ?? ''}',
      );

      transactions.insert(0, corrected);
      notifyListeners();
    }
  }

  void addCommitment(CommitmentModel commitment) {
    commitments.add(commitment);
    notifyListeners();
  }

  void markCommitmentPaid(String id, {bool logExpense = true}) {
    final idx = commitments.indexWhere((c) => c.id == id);
    if (idx != -1) {
      final com = commitments[idx];
      commitments[idx] = com.copyWith(isPaid: true);

      if (logExpense) {
        recordTransaction(
          TransactionModel(
            id: 'tx-${DateTime.now().millisecondsSinceEpoch}',
            categoryId: 'cat-commit',
            categoryName: 'Commitment Payment',
            amountCents: com.amountCents,
            type: 'expense',
            transactionDate: DateTime.now(),
            payee: com.title,
            note: 'Paid commitment: ${com.title}',
          ),
        );
      } else {
        notifyListeners();
      }
    }
  }

  void addSavingsGoal(SavingsGoalModel goal) {
    savingsGoals.add(goal);
    notifyListeners();
  }

  void adjustSavingsAllocation(String id, int deltaCents) {
    final idx = savingsGoals.indexWhere((s) => s.id == id);
    if (idx != -1) {
      final current = savingsGoals[idx];
      final updated = (current.currentAllocatedCents + deltaCents).clamp(0, current.targetCents * 2);
      savingsGoals[idx] = current.copyWith(currentAllocatedCents: updated);
      notifyListeners();
    }
  }

  // --- Notes Methods ---
  void addNote(NoteModel note) {
    notes.insert(0, note);
    notifyListeners();
  }

  void updateNote(NoteModel note) {
    final idx = notes.indexWhere((n) => n.id == note.id);
    if (idx != -1) {
      notes[idx] = note;
      notifyListeners();
    }
  }

  void deleteNote(String id) {
    notes.removeWhere((n) => n.id == id);
    notifyListeners();
  }

  void promoteNoteToTask(NoteModel note) {
    addTask(
      TaskModel(
        id: 'task-${DateTime.now().millisecondsSinceEpoch}',
        title: note.title,
        description: note.content,
        priority: 'medium',
        status: 'not_started',
        dueDate: DateTime.now().add(const Duration(days: 1)),
        projectId: note.projectId,
      ),
    );
  }

  // --- Quick Capture ---
  void addInboxItem(String text, String category) {
    final item = InboxItemModel(
      id: 'inbox-${DateTime.now().millisecondsSinceEpoch}',
      rawText: text,
      category: category,
    );
    inboxItems.insert(0, item);

    // If it's a task or expense, also add direct item
    if (category == 'task') {
      addTask(
        TaskModel(
          id: 'task-${DateTime.now().millisecondsSinceEpoch}',
          title: text,
          priority: 'medium',
          status: 'not_started',
          dueDate: DateTime.now().add(const Duration(days: 1)),
        ),
      );
    } else if (category == 'note') {
      addNote(
        NoteModel(
          id: 'note-${DateTime.now().millisecondsSinceEpoch}',
          title: text.length > 40 ? text.substring(0, 40) : text,
          content: text,
          category: 'general',
        ),
      );
    }

    notifyListeners();
  }

  // --- Encrypted Backup & Restore ---
  Future<String> exportEncryptedBackup(String passphrase) async {
    final stateMap = {
      'openingBalanceCents': openingBalanceCents,
      'tasks': tasks.map((t) => t.toJson()).toList(),
      'projects': projects.map((p) => p.toJson()).toList(),
      'transactions': transactions.map((t) => t.toJson()).toList(),
      'commitments': commitments.map((c) => c.toJson()).toList(),
      'savingsGoals': savingsGoals.map((s) => s.toJson()).toList(),
      'notes': notes.map((n) => n.toJson()).toList(),
      'inboxItems': inboxItems.map((i) => i.toJson()).toList(),
      // Double-Entry Ledger System Full State
      'accounts': accounts.map((a) => a.toJson()).toList(),
      'parties': parties.map((p) => p.toJson()).toList(),
      'journalEntries': journalEntries.map((e) => e.toJson()).toList(),
      'postings': postings.map((p) => p.toJson()).toList(),
      'debts': debts.map((d) => d.toJson()).toList(),
      'settlementAllocations': settlementAllocations.map((s) => s.toJson()).toList(),
    };

    final rawJson = jsonEncode(stateMap);
    return await _backupService.encryptDatabasePayload(
      rawDatabaseJson: rawJson,
      passphrase: passphrase,
      schemaVersion: 2,
    );
  }

  Future<bool> restoreFromEncryptedBackup(String encryptedEnvelopeJson, String passphrase) async {
    try {
      final decryptedJson = await _backupService.decryptDatabasePayload(
        encryptedEnvelopeJson: encryptedEnvelopeJson,
        passphrase: passphrase,
      );

      final Map<String, dynamic> stateMap = jsonDecode(decryptedJson);
      openingBalanceCents = stateMap['openingBalanceCents'] ?? openingBalanceCents;

      if (stateMap['tasks'] != null) {
        tasks = (stateMap['tasks'] as List).map((j) => TaskModel.fromJson(j)).toList();
      }
      if (stateMap['projects'] != null) {
        projects = (stateMap['projects'] as List).map((j) => ProjectModel.fromJson(j)).toList();
      }
      if (stateMap['transactions'] != null) {
        transactions = (stateMap['transactions'] as List).map((j) => TransactionModel.fromJson(j)).toList();
      }
      if (stateMap['commitments'] != null) {
        commitments = (stateMap['commitments'] as List).map((j) => CommitmentModel.fromJson(j)).toList();
      }
      if (stateMap['savingsGoals'] != null) {
        savingsGoals = (stateMap['savingsGoals'] as List).map((j) => SavingsGoalModel.fromJson(j)).toList();
      }
      if (stateMap['notes'] != null) {
        notes = (stateMap['notes'] as List).map((j) => NoteModel.fromJson(j)).toList();
      }
      if (stateMap['inboxItems'] != null) {
        inboxItems = (stateMap['inboxItems'] as List).map((j) => InboxItemModel.fromJson(j)).toList();
      }

      // Restore Double-Entry Ledger State
      if (stateMap['accounts'] != null) {
        accounts = (stateMap['accounts'] as List).map((j) => AccountModel.fromJson(j)).toList();
      }
      if (stateMap['parties'] != null) {
        parties = (stateMap['parties'] as List).map((j) => PartyModel.fromJson(j)).toList();
      }
      if (stateMap['journalEntries'] != null) {
        journalEntries = (stateMap['journalEntries'] as List).map((j) => JournalEntryModel.fromJson(j)).toList();
      }
      if (stateMap['postings'] != null) {
        postings = (stateMap['postings'] as List).map((j) => PostingModel.fromJson(j)).toList();
      }
      if (stateMap['debts'] != null) {
        debts = (stateMap['debts'] as List).map((j) => DebtModel.fromJson(j)).toList();
      }
      if (stateMap['settlementAllocations'] != null) {
        settlementAllocations = (stateMap['settlementAllocations'] as List).map((j) => SettlementAllocationModel.fromJson(j)).toList();
      }

      notifyListeners();
      return true;
    } catch (e) {
      return false;
    }
  }
}
