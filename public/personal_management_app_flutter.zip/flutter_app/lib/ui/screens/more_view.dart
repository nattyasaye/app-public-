import 'package:flutter/material.dart';
import '../app_state.dart';

class MoreView extends StatelessWidget {
  final AppStateManager state;
  final Function(String route) onNavigateSubScreen;

  const MoreView({
    super.key,
    required this.state,
    required this.onNavigateSubScreen,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'DAYWELL / ALL AREAS',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.2,
                color: Colors.grey.shade500,
              ),
            ),
            const Text(
              'Your space',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // User Profile Card
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: const Color(0xFFE0EFE8),
                    child: const Text(
                      'MR',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF1B4D3E),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Maya Rivera',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'A little more intentional, every day.',
                          style: TextStyle(fontSize: 11, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          // All Areas 8-Grid Section
          const Text(
            'All areas',
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),

          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.5,
            children: [
              _AreaCard(
                icon: Icons.track_changes_rounded,
                title: 'Goals',
                subtitle: '${state.savingsGoals.length} in progress',
                onTap: () => onNavigateSubScreen('finance'),
              ),
              _AreaCard(
                icon: Icons.menu_book_rounded,
                title: 'Notes & knowledge',
                subtitle: '${state.notes.length} in notes',
                onTap: () => onNavigateSubScreen('notes'),
              ),
              _AreaCard(
                icon: Icons.account_balance_wallet_rounded,
                title: 'Finance',
                subtitle: 'November overview',
                onTap: () => onNavigateSubScreen('finance'),
              ),
              _AreaCard(
                icon: Icons.people_outline_rounded,
                title: 'Relationships',
                subtitle: '3 coming up',
                onTap: () => onNavigateSubScreen('today'),
              ),
              _AreaCard(
                icon: Icons.list_alt_rounded,
                title: 'Priorities',
                subtitle: 'Your top 3',
                onTap: () => onNavigateSubScreen('tasks'),
              ),
              _AreaCard(
                icon: Icons.calculate_outlined,
                title: 'Calculations & tools',
                subtitle: 'Everyday utilities',
                onTap: () => onNavigateSubScreen('today'),
              ),
              _AreaCard(
                icon: Icons.bar_chart_rounded,
                title: 'History & progress',
                subtitle: 'Weekly summary',
                onTap: () => onNavigateSubScreen('today'),
              ),
              _AreaCard(
                icon: Icons.inbox_outlined,
                title: 'Inbox',
                subtitle: '${state.inboxItems.length} unorganized',
                onTap: () => onNavigateSubScreen('tasks'),
              ),
            ],
          ),

          const SizedBox(height: 24),

          // Make it yours Section
          const Text(
            'Make it yours',
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),

          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.brightness_medium_rounded, color: Color(0xFF1B4D3E)),
                  title: const Text('Appearance', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                  subtitle: const Text('System · Light / Dark', style: TextStyle(fontSize: 11)),
                  trailing: const Icon(Icons.chevron_right, size: 18),
                  onTap: () {},
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.notifications_outlined, color: Color(0xFF1B4D3E)),
                  title: const Text('Notifications & reminders', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                  subtitle: const Text('Schedules, sound & Android permissions', style: TextStyle(fontSize: 11)),
                  trailing: const Icon(Icons.chevron_right, size: 18),
                  onTap: () {},
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Your data Section
          const Text(
            'Your data',
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),

          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.sync_rounded, color: Color(0xFF1B4D3E)),
                  title: const Text('Sync & backup', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                  subtitle: const Text('Local save, sync status & recovery', style: TextStyle(fontSize: 11)),
                  trailing: const Icon(Icons.chevron_right, size: 18),
                  onTap: () => onNavigateSubScreen('backup'),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.send_rounded, color: Color(0xFF1B4D3E)),
                  title: const Text('Telegram backup', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                  subtitle: const Text('Configure external backup destination', style: TextStyle(fontSize: 11)),
                  trailing: const Icon(Icons.chevron_right, size: 18),
                  onTap: () => onNavigateSubScreen('backup'),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.security_rounded, color: Color(0xFF1B4D3E)),
                  title: const Text('Data management', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                  subtitle: const Text('AES-GCM-256 export & restore', style: TextStyle(fontSize: 11)),
                  trailing: const Icon(Icons.chevron_right, size: 18),
                  onTap: () => onNavigateSubScreen('backup'),
                ),
              ],
            ),
          ),

          const SizedBox(height: 32),
          const Text(
            'Daywell · A considered place for everyday life.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 11, color: Colors.grey),
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }
}

class _AreaCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _AreaCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.grey.withOpacity(0.15)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 20, color: const Color(0xFF1B4D3E)),
            const SizedBox(height: 6),
            Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 2),
            Text(
              subtitle,
              style: TextStyle(fontSize: 10, color: Colors.grey.shade500),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}
