import 'package:flutter/material.dart';
import '../../domain/calendar/ethiopian_calendar.dart';
import '../../domain/finance/financial_engine.dart';
import '../../domain/finance/double_entry_engine.dart';
import '../../services/export/finance_export_service.dart';
import '../app_state.dart';

class FinanceView extends StatefulWidget {
  final AppStateManager state;

  const FinanceView({super.key, required this.state});

  @override
  State<FinanceView> createState() => _FinanceViewState();
}

class _FinanceViewState extends State<FinanceView> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _showAddTransactionModal() {
    String mode = 'direct_expense'; // 'direct_expense', 'third_party_paid', 'lend', 'borrow', 'split'
    final amountController = TextEditingController();
    final descriptionController = TextEditingController();
    final partyNameController = TextEditingController(text: 'Abebe Kebede');
    final theirShareController = TextEditingController(text: '400');
    String selectedAssetAccount = 'acc-cbe';
    String selectedExpenseAccount = 'acc-exp-groceries';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                top: 20,
                left: 20,
                right: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Record Transaction (ገንዘብ መመዝገብ)',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () => Navigator.pop(ctx),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),

                    // Contextual Mode Selector
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          ChoiceChip(
                            label: const Text('I Paid Directly'),
                            selected: mode == 'direct_expense',
                            onSelected: (v) => setModalState(() => mode = 'direct_expense'),
                          ),
                          const SizedBox(width: 6),
                          ChoiceChip(
                            label: const Text('Someone Paid For Me'),
                            selected: mode == 'third_party_paid',
                            onSelected: (v) => setModalState(() => mode = 'third_party_paid'),
                          ),
                          const SizedBox(width: 6),
                          ChoiceChip(
                            label: const Text('I Lent Money'),
                            selected: mode == 'lend',
                            onSelected: (v) => setModalState(() => mode = 'lend'),
                          ),
                          const SizedBox(width: 6),
                          ChoiceChip(
                            label: const Text('I Borrowed'),
                            selected: mode == 'borrow',
                            onSelected: (v) => setModalState(() => mode = 'borrow'),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),

                    TextField(
                      controller: amountController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        labelText: 'Total Amount (ETB) *',
                        prefixText: 'ETB ',
                        border: OutlineInputBorder(),
                        hintText: 'e.g. 500.00',
                      ),
                      autofocus: true,
                    ),
                    const SizedBox(height: 12),

                    TextField(
                      controller: descriptionController,
                      decoration: const InputDecoration(
                        labelText: 'Description / Purpose *',
                        border: OutlineInputBorder(),
                        hintText: 'e.g. Lunch with team, Groceries',
                      ),
                    ),
                    const SizedBox(height: 12),

                    if (mode == 'direct_expense') ...[
                      DropdownButtonFormField<String>(
                        value: selectedAssetAccount,
                        decoration: const InputDecoration(labelText: 'Paid From Account', border: OutlineInputBorder()),
                        items: const [
                          DropdownMenuItem(value: 'acc-cbe', child: Text('CBE Bank Account (የኢትዮጵያ ንግድ ባንክ)')),
                          DropdownMenuItem(value: 'acc-telebirr', child: Text('Telebirr (ቴሌብር)')),
                          DropdownMenuItem(value: 'acc-cash', child: Text('Cash Wallet (ጥሬ ገንዘብ)')),
                        ],
                        onChanged: (v) => setModalState(() => selectedAssetAccount = v!),
                      ),
                    ] else if (mode == 'third_party_paid') ...[
                      TextField(
                        controller: partyNameController,
                        decoration: const InputDecoration(
                          labelText: 'Who Paid For You? *',
                          border: OutlineInputBorder(),
                          hintText: 'e.g. Abebe Kebede',
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Note: This records your expense today without deducting from your bank balance until you settle the debt.',
                        style: TextStyle(fontSize: 11, color: Colors.blueGrey),
                      ),
                    ] else if (mode == 'lend') ...[
                      TextField(
                        controller: partyNameController,
                        decoration: const InputDecoration(
                          labelText: 'Who Borrowed From You? *',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        value: selectedAssetAccount,
                        decoration: const InputDecoration(labelText: 'Source of Funds', border: OutlineInputBorder()),
                        items: const [
                          DropdownMenuItem(value: 'acc-cash', child: Text('Cash Wallet')),
                          DropdownMenuItem(value: 'acc-cbe', child: Text('CBE Account')),
                          DropdownMenuItem(value: 'acc-telebirr', child: Text('Telebirr')),
                        ],
                        onChanged: (v) => setModalState(() => selectedAssetAccount = v!),
                      ),
                    ] else if (mode == 'borrow') ...[
                      TextField(
                        controller: partyNameController,
                        decoration: const InputDecoration(
                          labelText: 'Lender Name (Who lent you?) *',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        value: selectedAssetAccount,
                        decoration: const InputDecoration(labelText: 'Deposited Into', border: OutlineInputBorder()),
                        items: const [
                          DropdownMenuItem(value: 'acc-telebirr', child: Text('Telebirr')),
                          DropdownMenuItem(value: 'acc-cbe', child: Text('CBE Account')),
                          DropdownMenuItem(value: 'acc-cash', child: Text('Cash Wallet')),
                        ],
                        onChanged: (v) => setModalState(() => selectedAssetAccount = v!),
                      ),
                    ],

                    const SizedBox(height: 18),
                    ElevatedButton.icon(
                      onPressed: () {
                        final cents = FinancialEngine.parseToCents(amountController.text);
                        final desc = descriptionController.text.trim();
                        final partyName = partyNameController.text.trim();
                        final today = DateTime.now().toIso8601String().substring(0, 10);

                        if (cents > 0 && desc.isNotEmpty) {
                          final targetPartyId = widget.state.ensurePartyId(
                            partyName.isNotEmpty ? partyName : 'Abebe Kebede',
                          );

                          if (mode == 'direct_expense') {
                            widget.state.addDoubleEntryDirectExpense(
                              assetAccountId: selectedAssetAccount,
                              expenseAccountId: selectedExpenseAccount,
                              amountCents: cents,
                              description: desc,
                              occurrenceDate: today,
                            );
                          } else if (mode == 'third_party_paid') {
                            widget.state.addDoubleEntryThirdPartyPaid(
                              partyId: targetPartyId,
                              expenseAccountId: selectedExpenseAccount,
                              payableAccountId: 'acc-pay',
                              amountCents: cents,
                              occurrenceDate: today,
                              description: '$desc (Paid by ${partyName.isNotEmpty ? partyName : "Contact"})',
                            );
                          } else if (mode == 'lend') {
                            widget.state.addDoubleEntryLendMoney(
                              partyId: targetPartyId,
                              sourceAssetAccountId: selectedAssetAccount,
                              amountCents: cents,
                              date: today,
                              description: 'Lent to ${partyName.isNotEmpty ? partyName : "Contact"}: $desc',
                            );
                          } else if (mode == 'borrow') {
                            widget.state.addDoubleEntryBorrowMoney(
                              partyId: targetPartyId,
                              destAssetAccountId: selectedAssetAccount,
                              amountCents: cents,
                              date: today,
                              description: 'Borrowed from ${partyName.isNotEmpty ? partyName : "Contact"}: $desc',
                            );
                          }
                          Navigator.pop(ctx);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Recorded ${FinancialEngine.formatBirr(cents)}: $desc'),
                              duration: const Duration(seconds: 5),
                              action: SnackBarAction(
                                label: 'UNDO',
                                textColor: const Color(0xFF81C784),
                                onPressed: () {
                                  // Revert top entry if user touches undo
                                  if (widget.state.journalEntries.isNotEmpty) {
                                    widget.state.voidJournalEntry(
                                      widget.state.journalEntries.first.id,
                                      'User undo within 5 seconds',
                                    );
                                  }
                                },
                              ),
                            ),
                          );
                        }
                      },
                      icon: const Icon(Icons.check),
                      label: const Text('Save Journal Entry'),
                      style: ElevatedButton.styleFrom(
                        minimumSize: const Size.fromHeight(48),
                        backgroundColor: const Color(0xFF1B4D3E),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showSettlementDialog(DebtModel debt) {
    final amountController = TextEditingController(text: (debt.outstandingCents / 100).toStringAsFixed(2));
    final interestController = TextEditingController(text: '0.00');
    final descController = TextEditingController(text: 'Debt settlement repayment');
    String assetAccountId = 'acc-cbe';

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: Text(debt.debtType == DebtType.payable ? 'Settle Debt I Owe' : 'Collect Repayment'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Outstanding Principal: ${FinancialEngine.formatBirr(debt.outstandingCents)}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: amountController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Principal Amount to Settle (ETB) *', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: interestController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Optional Interest (ETB)', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: assetAccountId,
                decoration: const InputDecoration(labelText: 'Payment Account', border: OutlineInputBorder()),
                items: const [
                  DropdownMenuItem(value: 'acc-cbe', child: Text('CBE Bank Account')),
                  DropdownMenuItem(value: 'acc-telebirr', child: Text('Telebirr')),
                  DropdownMenuItem(value: 'acc-cash', child: Text('Cash Wallet')),
                ],
                onChanged: (v) => assetAccountId = v!,
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () {
                final cents = FinancialEngine.parseToCents(amountController.text);
                final interest = FinancialEngine.parseToCents(interestController.text);
                final today = DateTime.now().toIso8601String().substring(0, 10);
                if (cents > 0) {
                  widget.state.recordDoubleEntrySettlement(
                    debt: debt,
                    settlementAssetAccountId: assetAccountId,
                    allocatedCents: cents,
                    interestCents: interest,
                    settlementDate: today,
                    description: descController.text.trim(),
                  );
                  Navigator.pop(ctx);
                }
              },
              child: const Text('Record Settlement'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final netPos = widget.state.netFinancialPositionCents;
    final avail = widget.state.availableToSpendCents;
    final liquid = widget.state.liquidCashCents;
    final rec = widget.state.totalReceivablesCents;
    final pay = widget.state.totalPayablesCents;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Daywell Finance (ETB)'),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          tabs: [
            Tab(text: 'Occurrence P&L (${widget.state.journalEntries.length})'),
            Tab(text: 'Cash Flow (${widget.state.postings.length})'),
            Tab(text: 'Debts & Loans (${widget.state.debts.length})'),
            const Tab(text: 'Data Portability (Export)'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFF1B4D3E),
        foregroundColor: Colors.white,
        onPressed: _showAddTransactionModal,
        icon: const Icon(Icons.add),
        label: const Text('Record Entry'),
      ),
      body: Column(
        children: [
          // Top Hero Financial Metrics Card
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.5),
              border: Border(bottom: BorderSide(color: Colors.grey.shade300)),
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('NET FINANCIAL POSITION', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.grey)),
                        const SizedBox(height: 4),
                        Text(FinancialEngine.formatBirr(netPos), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Text('AVAILABLE TO SPEND', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF1B4D3E))),
                        const SizedBox(height: 4),
                        Text(FinancialEngine.formatBirr(avail), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1B4D3E))),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Liquid Cash: ${FinancialEngine.formatBirr(liquid)}', style: const TextStyle(fontSize: 11, color: Colors.blueGrey)),
                    Text('Receivables: +${FinancialEngine.formatBirr(rec)}', style: const TextStyle(fontSize: 11, color: Colors.teal)),
                    Text('Payables: -${FinancialEngine.formatBirr(pay)}', style: const TextStyle(fontSize: 11, color: Colors.deepOrange)),
                  ],
                ),
              ],
            ),
          ),

          // Tab Views
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                // Tab 1: Occurrence P&L
                ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: widget.state.journalEntries.length,
                  itemBuilder: (ctx, i) {
                    final j = widget.state.journalEntries[i];
                    final entryPostings = widget.state.postings.where((p) => p.entryId == j.id).toList();

                    return Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(j.description, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(6)),
                                  child: Text(j.entryType.name.toUpperCase(), style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold)),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text('Occurrence Date: ${j.occurrenceDate}', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                            const Divider(height: 16),
                            Column(
                              children: entryPostings.map((p) {
                                final isDebit = p.direction == PostingDirection.debit;
                                return Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text('${isDebit ? "DR" : "CR"} · ${p.accountId}', style: TextStyle(fontSize: 12, color: isDebit ? Colors.green.shade800 : Colors.red.shade800)),
                                    Text(FinancialEngine.formatBirr(p.amountCents), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                                  ],
                                );
                              }).toList(),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),

                // Tab 2: Cash Flow (Actual Account Movement)
                ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: widget.state.postings.length,
                  itemBuilder: (ctx, i) {
                    final p = widget.state.postings[i];
                    final isDebit = p.direction == PostingDirection.debit;

                    return Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: isDebit ? Colors.green.shade50 : Colors.red.shade50,
                          child: Icon(isDebit ? Icons.arrow_downward : Icons.arrow_upward, color: isDebit ? Colors.green : Colors.red, size: 18),
                        ),
                        title: Text(p.accountId, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                        subtitle: Text('Movement: ${p.accountMovementDate} • ${isDebit ? "Inflow (DR)" : "Outflow (CR)"}', style: const TextStyle(fontSize: 11)),
                        trailing: Text(
                          '${isDebit ? "+" : "-"}${FinancialEngine.formatBirr(p.amountCents)}',
                          style: TextStyle(fontWeight: FontWeight.bold, color: isDebit ? Colors.green.shade800 : Colors.red.shade800),
                        ),
                      ),
                    );
                  },
                ),

                // Tab 3: Debts Hub
                ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: widget.state.debts.length,
                  itemBuilder: (ctx, i) {
                    final d = widget.state.debts[i];
                    final isReceivable = d.debtType == DebtType.receivable;

                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Icon(isReceivable ? Icons.call_received : Icons.call_made, color: isReceivable ? Colors.teal : Colors.deepOrange, size: 18),
                                    const SizedBox(width: 6),
                                    Text(
                                      isReceivable ? 'RECEIVABLE (Owed to Me)' : 'PAYABLE (I Owe)',
                                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: isReceivable ? Colors.teal : Colors.deepOrange),
                                    ),
                                  ],
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: d.status == DebtStatus.settled ? Colors.green.shade100 : Colors.orange.shade100,
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(d.status.name.toUpperCase(), style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold)),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text('Party: ${d.partyId}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 4),
                            Text('Original Principal: ${FinancialEngine.formatBirr(d.principalCents)}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                            Text('Outstanding Balance: ${FinancialEngine.formatBirr(d.outstandingCents)}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                            if (d.status == DebtStatus.active) ...[
                              const SizedBox(height: 10),
                              Align(
                                alignment: Alignment.centerRight,
                                child: ElevatedButton.icon(
                                  onPressed: () => _showSettlementDialog(d),
                                  icon: const Icon(Icons.handshake, size: 16),
                                  label: Text(isReceivable ? 'Collect Repayment' : 'Repay Debt'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: isReceivable ? Colors.teal : Colors.deepOrange,
                                    foregroundColor: Colors.white,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    );
                  },
                ),

                // Tab 4: Data Portability & Independent Analysis
                SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Data Portability & Independent Analysis',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Export complete normalized financial records, independent of application UI. Compatible with Excel, SQLite, and analytical scripts.',
                        style: TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                      const SizedBox(height: 16),

                      Card(
                        child: ListTile(
                          leading: const Icon(Icons.table_view, color: Colors.green),
                          title: const Text('Export Normalized CSVs (UTF-8 with BOM)'),
                          subtitle: const Text('Accounts, Parties, Journal Entries, Postings, Debts, Allocations'),
                          trailing: const Icon(Icons.download),
                          onTap: () {
                            final csv = FinanceExportService.exportPostingsCsv(widget.state.postings);
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Generated CSV export with ${widget.state.postings.length} postings.')),
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 8),

                      Card(
                        child: ListTile(
                          leading: const Icon(Icons.storage, color: Colors.blue),
                          title: const Text('Export SQLite Analytical Database (.sql)'),
                          subtitle: const Text('PRAGMA foreign_keys = ON, Analytical balance & cash-flow views'),
                          trailing: const Icon(Icons.download),
                          onTap: () {
                            final sql = FinanceExportService.exportSqliteAnalyticalScript(
                              accounts: widget.state.accounts,
                              parties: widget.state.parties,
                              entries: widget.state.journalEntries,
                              postings: widget.state.postings,
                              debts: widget.state.debts,
                              allocations: widget.state.settlementAllocations,
                            );
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Generated SQLite analytical schema and transactional seed.')),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
