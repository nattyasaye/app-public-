import 'package:flutter/material.dart';
import '../../domain/calendar/ethiopian_calendar.dart';
import '../app_state.dart';

class NotesView extends StatefulWidget {
  final AppStateManager state;

  const NotesView({super.key, required this.state});

  @override
  State<NotesView> createState() => _NotesViewState();
}

class _NotesViewState extends State<NotesView> {
  String _searchQuery = '';
  String _categoryFilter = 'all';

  void _showAddEditNoteDialog([NoteModel? existingNote]) {
    final titleController = TextEditingController(text: existingNote?.title ?? '');
    final contentController = TextEditingController(text: existingNote?.content ?? '');
    String category = existingNote?.category ?? 'reflection';
    String? projectId = existingNote?.projectId;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                top: 20,
                left: 20,
                right: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        existingNote == null ? 'New Note (ማስታወሻ)' : 'Edit Note',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () => Navigator.pop(ctx),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: titleController,
                    decoration: const InputDecoration(
                      labelText: 'Title *',
                      border: OutlineInputBorder(),
                      hintText: 'e.g. Life Vision or Technical Architecture',
                    ),
                    autofocus: true,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: contentController,
                    decoration: const InputDecoration(
                      labelText: 'Content (English & Amharic / ፊደል) *',
                      border: OutlineInputBorder(),
                    ),
                    maxLines: 5,
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Text('Category: ', style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(width: 8),
                      DropdownButton<String>(
                        value: category,
                        items: const [
                          DropdownMenuItem(value: 'reflection', child: Text('Reflection (ግምገማ)')),
                          DropdownMenuItem(value: 'reference', child: Text('Reference (ማጣቀሻ)')),
                          DropdownMenuItem(value: 'learning', child: Text('Learning (ትምህርት)')),
                          DropdownMenuItem(value: 'general', child: Text('General (አጠቃላይ)')),
                        ],
                        onChanged: (val) {
                          if (val != null) setModalState(() => category = val);
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    onPressed: () {
                      final title = titleController.text.trim();
                      final content = contentController.text.trim();
                      if (title.isNotEmpty && content.isNotEmpty) {
                        if (existingNote == null) {
                          widget.state.addNote(
                            NoteModel(
                              id: 'note-${DateTime.now().millisecondsSinceEpoch}',
                              title: title,
                              content: content,
                              category: category,
                              projectId: projectId,
                            ),
                          );
                        } else {
                          widget.state.updateNote(
                            existingNote.copyWith(
                              title: title,
                              content: content,
                              category: category,
                              projectId: projectId,
                            ),
                          );
                        }
                        Navigator.pop(ctx);
                      }
                    },
                    icon: const Icon(Icons.check),
                    label: Text(existingNote == null ? 'Save Note' : 'Update Note'),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(48),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final notes = widget.state.notes.where((n) {
      if (_categoryFilter != 'all' && n.category != _categoryFilter) return false;
      if (_searchQuery.isNotEmpty) {
        final q = _searchQuery.toLowerCase();
        final matchesTitle = n.title.toLowerCase().contains(q);
        final matchesContent = n.content.toLowerCase().contains(q);
        return matchesTitle || matchesContent;
      }
      return true;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notes & Knowledge Base'),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddEditNoteDialog(),
        icon: const Icon(Icons.add),
        label: const Text('Add Note'),
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search notes (English & አማርኛ ፊደል)...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                filled: true,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
              ),
              onChanged: (val) => setState(() => _searchQuery = val.trim()),
            ),
          ),

          // Category Chips
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: [
                FilterChip(
                  label: const Text('All'),
                  selected: _categoryFilter == 'all',
                  onSelected: (_) => setState(() => _categoryFilter = 'all'),
                ),
                const SizedBox(width: 8),
                FilterChip(
                  label: const Text('Reflection'),
                  selected: _categoryFilter == 'reflection',
                  onSelected: (_) => setState(() => _categoryFilter = 'reflection'),
                ),
                const SizedBox(width: 8),
                FilterChip(
                  label: const Text('Reference'),
                  selected: _categoryFilter == 'reference',
                  onSelected: (_) => setState(() => _categoryFilter = 'reference'),
                ),
                const SizedBox(width: 8),
                FilterChip(
                  label: const Text('Learning'),
                  selected: _categoryFilter == 'learning',
                  onSelected: (_) => setState(() => _categoryFilter = 'learning'),
                ),
              ],
            ),
          ),

          Expanded(
            child: notes.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.notes, size: 64, color: Colors.grey.shade400),
                        const SizedBox(height: 12),
                        Text(
                          'No notes found',
                          style: TextStyle(color: Colors.grey.shade600, fontSize: 16),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: notes.length,
                    itemBuilder: (ctx, i) {
                      final n = notes[i];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        child: InkWell(
                          onTap: () => _showAddEditNoteDialog(n),
                          borderRadius: BorderRadius.circular(16),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Text(
                                        n.title,
                                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Theme.of(context).colorScheme.secondaryContainer,
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Text(
                                        n.category.toUpperCase(),
                                        style: TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold,
                                          color: Theme.of(context).colorScheme.onSecondaryContainer,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  n.content,
                                  maxLines: 3,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(color: Colors.grey.shade800, height: 1.3),
                                ),
                                const SizedBox(height: 12),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      EthiopianCalendar.formatDual(n.createdAt),
                                      style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                                    ),
                                    Row(
                                      children: [
                                        TextButton.icon(
                                          onPressed: () {
                                            widget.state.promoteNoteToTask(n);
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(content: Text('Note promoted to Task!')),
                                            );
                                          },
                                          icon: const Icon(Icons.arrow_forward_rounded, size: 14),
                                          label: const Text('To Task', style: TextStyle(fontSize: 12)),
                                        ),
                                        IconButton(
                                          icon: const Icon(Icons.delete_outline, size: 18),
                                          onPressed: () => widget.state.deleteNote(n.id),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
