import 'package:flutter/material.dart';
import '../../domain/calendar/ethiopian_calendar.dart';
import '../app_state.dart';

class TasksView extends StatefulWidget {
  final AppStateManager state;

  const TasksView({super.key, required this.state});

  @override
  State<TasksView> createState() => _TasksViewState();
}

class _TasksViewState extends State<TasksView> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _taskFilter = 'active'; // 'all', 'active', 'completed'
  String _priorityFilter = 'all'; // 'all', 'urgent', 'high', 'medium', 'low'

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _showAddTaskDialog() {
    final titleController = TextEditingController();
    final descController = TextEditingController();
    String priority = 'medium';
    String? selectedProjectId;
    DateTime selectedDate = DateTime.now().add(const Duration(days: 1));

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                top: 20,
                left: 20,
                right: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'New Task (አዲስ ተግባር)',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () => Navigator.pop(ctx),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: titleController,
                    decoration: const InputDecoration(
                      labelText: 'Task Title *',
                      border: OutlineInputBorder(),
                      hintText: 'e.g. Prepare financial statement',
                    ),
                    autofocus: true,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: descController,
                    decoration: const InputDecoration(
                      labelText: 'Description (Optional)',
                      border: OutlineInputBorder(),
                    ),
                    maxLines: 2,
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      const Text('Priority: ', style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(width: 8),
                      DropdownButton<String>(
                        value: priority,
                        items: const [
                          DropdownMenuItem(value: 'urgent', child: Text('🔴 Urgent')),
                          DropdownMenuItem(value: 'high', child: Text('🟠 High')),
                          DropdownMenuItem(value: 'medium', child: Text('🟡 Medium')),
                          DropdownMenuItem(value: 'low', child: Text('🟢 Low')),
                        ],
                        onChanged: (val) {
                          if (val != null) setModalState(() => priority = val);
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (widget.state.projects.isNotEmpty)
                    Row(
                      children: [
                        const Text('Project: ', style: TextStyle(fontWeight: FontWeight.bold)),
                        const SizedBox(width: 8),
                        DropdownButton<String?>(
                          value: selectedProjectId,
                          hint: const Text('None (Independent)'),
                          items: [
                            const DropdownMenuItem(value: null, child: Text('None (Independent)')),
                            ...widget.state.projects.map((p) => DropdownMenuItem(
                                  value: p.id,
                                  child: Text(p.title.length > 25 ? '${p.title.substring(0, 25)}...' : p.title),
                                )),
                          ],
                          onChanged: (val) => setModalState(() => selectedProjectId = val),
                        ),
                      ],
                    ),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    onPressed: () {
                      final title = titleController.text.trim();
                      if (title.isNotEmpty) {
                        widget.state.addTask(
                          TaskModel(
                            id: 'task-${DateTime.now().millisecondsSinceEpoch}',
                            title: title,
                            description: descController.text.trim().isNotEmpty ? descController.text.trim() : null,
                            priority: priority,
                            dueDate: selectedDate,
                            projectId: selectedProjectId,
                          ),
                        );
                        Navigator.pop(ctx);
                      }
                    },
                    icon: const Icon(Icons.check),
                    label: const Text('Save Task'),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(48),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _showAddProjectDialog() {
    final titleController = TextEditingController();
    final descController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            top: 20,
            left: 20,
            right: 20,
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'New Project (አዲስ ፕሮጀክት)',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: titleController,
                decoration: const InputDecoration(
                  labelText: 'Project Title *',
                  border: OutlineInputBorder(),
                  hintText: 'e.g. Real Estate Development',
                ),
                autofocus: true,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: descController,
                decoration: const InputDecoration(
                  labelText: 'Description / Desired Outcome',
                  border: OutlineInputBorder(),
                ),
                maxLines: 2,
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () {
                  final title = titleController.text.trim();
                  if (title.isNotEmpty) {
                    widget.state.addProject(
                      ProjectModel(
                        id: 'proj-${DateTime.now().millisecondsSinceEpoch}',
                        title: title,
                        description: descController.text.trim().isNotEmpty ? descController.text.trim() : null,
                        targetDate: DateTime.now().add(const Duration(days: 30)),
                      ),
                    );
                    Navigator.pop(ctx);
                  }
                },
                icon: const Icon(Icons.folder_outlined),
                label: const Text('Create Project'),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(48),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final tasks = widget.state.tasks.where((t) {
      if (_taskFilter == 'active' && t.status == 'completed') return false;
      if (_taskFilter == 'completed' && t.status != 'completed') return false;
      if (_priorityFilter != 'all' && t.priority != _priorityFilter) return false;
      return true;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tasks & Projects'),
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: 'Tasks (${widget.state.tasks.where((t) => t.status != 'completed').length})'),
            Tab(text: 'Projects (${widget.state.projects.length})'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          if (_tabController.index == 0) {
            _showAddTaskDialog();
          } else {
            _showAddProjectDialog();
          }
        },
        icon: const Icon(Icons.add),
        label: Text(_tabController.index == 0 ? 'Add Task' : 'Add Project'),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // Tab 1: Tasks
          Column(
            children: [
              // Filter Chips
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    FilterChip(
                      label: const Text('Active'),
                      selected: _taskFilter == 'active',
                      onSelected: (_) => setState(() => _taskFilter = 'active'),
                    ),
                    const SizedBox(width: 8),
                    FilterChip(
                      label: const Text('All Tasks'),
                      selected: _taskFilter == 'all',
                      onSelected: (_) => setState(() => _taskFilter = 'all'),
                    ),
                    const SizedBox(width: 8),
                    FilterChip(
                      label: const Text('Completed'),
                      selected: _taskFilter == 'completed',
                      onSelected: (_) => setState(() => _taskFilter = 'completed'),
                    ),
                    const SizedBox(width: 12),
                    const Text('|'),
                    const SizedBox(width: 12),
                    FilterChip(
                      label: const Text('Urgent Only'),
                      selected: _priorityFilter == 'urgent',
                      onSelected: (sel) => setState(() => _priorityFilter = sel ? 'urgent' : 'all'),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: tasks.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.task_alt, size: 64, color: Colors.grey.shade400),
                            const SizedBox(height: 12),
                            Text(
                              'No tasks match this filter',
                              style: TextStyle(color: Colors.grey.shade600, fontSize: 16),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: tasks.length,
                        itemBuilder: (ctx, i) {
                          final t = tasks[i];
                          return Card(
                            margin: const EdgeInsets.only(bottom: 10),
                            child: ListTile(
                              leading: Checkbox(
                                value: t.status == 'completed',
                                onChanged: (_) => widget.state.toggleTaskStatus(t.id),
                              ),
                              title: Text(
                                t.title,
                                style: TextStyle(
                                  decoration: t.status == 'completed' ? TextDecoration.lineThrough : null,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  if (t.description != null)
                                    Text(t.description!, maxLines: 2, overflow: TextOverflow.ellipsis),
                                  if (t.dueDate != null)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 4),
                                      child: Text(
                                        'Due: ${EthiopianCalendar.formatDual(t.dueDate!)}',
                                        style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                                      ),
                                    ),
                                ],
                              ),
                              trailing: IconButton(
                                icon: const Icon(Icons.delete_outline, size: 20),
                                onPressed: () => widget.state.deleteTask(t.id),
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),

          // Tab 2: Projects
          widget.state.projects.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.folder_open, size: 64, color: Colors.grey.shade400),
                      const SizedBox(height: 12),
                      Text(
                        'No projects created yet',
                        style: TextStyle(color: Colors.grey.shade600, fontSize: 16),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: widget.state.projects.length,
                  itemBuilder: (ctx, i) {
                    final p = widget.state.projects[i];
                    final progress = widget.state.getProjectProgress(p.id);

                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Text(
                                    p.title,
                                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Theme.of(context).colorScheme.primaryContainer,
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Text(
                                    '$progress%',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            if (p.description != null) ...[
                              const SizedBox(height: 6),
                              Text(p.description!, style: TextStyle(color: Colors.grey.shade700, fontSize: 13)),
                            ],
                            const SizedBox(height: 12),
                            LinearProgressIndicator(
                              value: progress / 100,
                              minHeight: 6,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            const SizedBox(height: 8),
                            if (p.targetDate != null)
                              Text(
                                'Target: ${EthiopianCalendar.formatDual(p.targetDate!)}',
                                style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ],
      ),
    );
  }
}
