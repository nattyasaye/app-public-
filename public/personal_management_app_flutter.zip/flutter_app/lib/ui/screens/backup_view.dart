import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../app_state.dart';

class BackupView extends StatefulWidget {
  final AppStateManager state;

  const BackupView({super.key, required this.state});

  @override
  State<BackupView> createState() => _BackupViewState();
}

class _BackupViewState extends State<BackupView> {
  final _passphraseController = TextEditingController();
  final _restorePayloadController = TextEditingController();
  final _restorePassphraseController = TextEditingController();

  bool _obscureExport = true;
  bool _obscureRestore = true;
  bool _isProcessing = false;
  String? _exportedPayload;

  Future<void> _handleExport() async {
    final pass = _passphraseController.text.trim();
    if (pass.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a secret passphrase')),
      );
      return;
    }

    setState(() => _isProcessing = true);
    try {
      final encrypted = await widget.state.exportEncryptedBackup(pass);
      setState(() {
        _exportedPayload = encrypted;
        _isProcessing = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Encrypted backup generated (AES-GCM-256)!')),
        );
      }
    } catch (e) {
      setState(() => _isProcessing = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Export failed: $e')),
        );
      }
    }
  }

  Future<void> _handleRestore() async {
    final payload = _restorePayloadController.text.trim();
    final pass = _restorePassphraseController.text.trim();

    if (payload.isEmpty || pass.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter both encrypted backup payload and passphrase')),
      );
      return;
    }

    setState(() => _isProcessing = true);
    final success = await widget.state.restoreFromEncryptedBackup(payload, pass);
    setState(() => _isProcessing = false);

    if (mounted) {
      if (success) {
        _restorePayloadController.clear();
        _restorePassphraseController.clear();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Database restored successfully and integrity verified!')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Restore failed: Incorrect passphrase or corrupted checksum.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Backup & Offline Security'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Offline Security Badge
          Card(
            color: Colors.green.shade50,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.verified_user, color: Colors.green, size: 36),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          '100% Offline Sovereignty',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.green),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'No cloud servers, no trackers, zero remote dependencies. All data is kept locally on your phone.',
                          style: TextStyle(fontSize: 12, color: Colors.green.shade900),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          // Database Statistics
          Text('Local Database Statistics', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _StatRow(label: 'Total Tasks', value: '${widget.state.tasks.length}'),
                  const Divider(),
                  _StatRow(label: 'Projects', value: '${widget.state.projects.length}'),
                  const Divider(),
                  _StatRow(label: 'Financial Transactions', value: '${widget.state.transactions.length}'),
                  const Divider(),
                  _StatRow(label: 'Commitments & Bills', value: '${widget.state.commitments.length}'),
                  const Divider(),
                  _StatRow(label: 'Savings Goals', value: '${widget.state.savingsGoals.length}'),
                  const Divider(),
                  _StatRow(label: 'Notes & Reflections', value: '${widget.state.notes.length}'),
                ],
              ),
            ),
          ),

          const SizedBox(height: 24),

          // Export Encrypted Backup Card
          Text('Export Encrypted Backup (.pmbackup)', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Derives an encryption key via PBKDF2 (100,000 rounds) and seals entire SQLite state with AES-GCM-256 authenticated encryption.',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _passphraseController,
                    obscureText: _obscureExport,
                    decoration: InputDecoration(
                      labelText: 'Master Passphrase *',
                      border: const OutlineInputBorder(),
                      suffixIcon: IconButton(
                        icon: Icon(_obscureExport ? Icons.visibility : Icons.visibility_off),
                        onPressed: () => setState(() => _obscureExport = !_obscureExport),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    onPressed: _isProcessing ? null : _handleExport,
                    icon: _isProcessing
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.lock_outline),
                    label: const Text('Generate Encrypted Backup'),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(48),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                  if (_exportedPayload != null) ...[
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Encrypted Envelope Ready', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                              IconButton(
                                icon: const Icon(Icons.copy, size: 18),
                                tooltip: 'Copy to Clipboard',
                                onPressed: () {
                                  Clipboard.setData(ClipboardData(text: _exportedPayload!));
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('Backup envelope copied to clipboard!')),
                                  );
                                },
                              ),
                            ],
                          ),
                          Text(
                            _exportedPayload!.substring(0, 120) + '...',
                            style: const TextStyle(fontFamily: 'monospace', fontSize: 10),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),

          const SizedBox(height: 24),

          // Restore Backup Card
          Text('Restore from Encrypted Backup', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  TextField(
                    controller: _restorePayloadController,
                    decoration: const InputDecoration(
                      labelText: 'Paste Encrypted Backup JSON',
                      border: OutlineInputBorder(),
                    ),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _restorePassphraseController,
                    obscureText: _obscureRestore,
                    decoration: InputDecoration(
                      labelText: 'Passphrase *',
                      border: const OutlineInputBorder(),
                      suffixIcon: IconButton(
                        icon: Icon(_obscureRestore ? Icons.visibility : Icons.visibility_off),
                        onPressed: () => setState(() => _obscureRestore = !_obscureRestore),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    onPressed: _isProcessing ? null : _handleRestore,
                    icon: const Icon(Icons.restore),
                    label: const Text('Decrypt & Restore State'),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(48),
                      backgroundColor: Colors.teal.shade700,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }
}

class _StatRow extends StatelessWidget {
  final String label;
  final String value;

  const _StatRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 14)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        ],
      ),
    );
  }
}
