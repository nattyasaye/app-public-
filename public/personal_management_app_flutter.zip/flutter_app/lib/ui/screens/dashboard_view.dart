import 'package:flutter/material.dart';
import '../../domain/calendar/ethiopian_calendar.dart';
import '../../domain/finance/financial_engine.dart';
import '../app_state.dart';

class DashboardView extends StatelessWidget {
  final AppStateManager state;
  final VoidCallback onOpenQuickCapture;
  final Function(int) onNavigateTab;

  const DashboardView({
    super.key,
    required this.state,
    required this.onOpenQuickCapture,
    required this.onNavigateTab,
  });

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final dualDate = EthiopianCalendar.formatDual(now);
    final snapshot = state.financialSnapshot;

    final pendingTasks = state.tasks.where((t) => t.status != 'completed' && t.status != 'cancelled').toList();
    final urgentTasks = pendingTasks.where((t) => t.priority == 'urgent' || t.priority == 'high').toList();
    final pendingCommitments = state.commitments.where((c) => !c.isPaid).toList();

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Personal Management',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Text(
              dualDate,
              style: TextStyle(
                fontSize: 12,
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.flash_on_rounded),
            tooltip: '1-Tap Quick Capture',
            onPressed: onOpenQuickCapture,
          ),
          IconButton(
            icon: const Icon(Icons.shield_outlined),
            tooltip: 'Encrypted Backup',
            onPressed: () => onNavigateTab(4),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          // Re-render
        },
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Available to spend Hero Card
            Card(
              elevation: 3,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              color: Theme.of(context).colorScheme.primaryContainer,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'AVAILABLE TO SPEND',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.2,
                            color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.8),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primary,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Text(
                            'SAFE HARBOR',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      FinancialEngine.formatBirr(state.availableToSpendCents),
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.w900,
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Divider(color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.2)),
                    const SizedBox(height: 8),
                    Text(
                      'Double-Entry Formula: Liquid Cash (${FinancialEngine.formatBirr(state.liquidCashCents)}) - Due Payables (${FinancialEngine.formatBirr(state.totalPayablesCents)}) - Savings | Net Position: ${FinancialEngine.formatBirr(state.netFinancialPositionCents)}',
                      style: TextStyle(
                        fontSize: 11,
                        color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.9),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),

            // Quick Metrics Grid
            Row(
              children: [
                Expanded(
                  child: _MetricCard(
                    title: 'Active Tasks',
                    value: '${pendingTasks.length}',
                    icon: Icons.check_circle_outline,
                    color: Colors.blue,
                    onTap: () => onNavigateTab(1),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _MetricCard(
                    title: 'Commitments',
                    value: '${pendingCommitments.length}',
                    icon: Icons.receipt_long_outlined,
                    color: Colors.amber.shade800,
                    onTap: () => onNavigateTab(2),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _MetricCard(
                    title: 'Notes',
                    value: '${state.notes.length}',
                    icon: Icons.menu_book_outlined,
                    color: Colors.teal,
                    onTap: () => onNavigateTab(3),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            // Quick Actions Bar
            Text(
              'Quick Actions',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _ActionButton(
                    icon: Icons.add_task_rounded,
                    label: '+ Task',
                    onTap: () => onNavigateTab(1),
                  ),
                  const SizedBox(width: 8),
                  _ActionButton(
                    icon: Icons.remove_circle_outline,
                    label: '+ Expense',
                    onTap: () => onNavigateTab(2),
                  ),
                  const SizedBox(width: 8),
                  _ActionButton(
                    icon: Icons.add_circle_outline,
                    label: '+ Income',
                    onTap: () => onNavigateTab(2),
                  ),
                  const SizedBox(width: 8),
                  _ActionButton(
                    icon: Icons.note_add_outlined,
                    label: '+ Note',
                    onTap: () => onNavigateTab(3),
                  ),
                  const SizedBox(width: 8),
                  _ActionButton(
                    icon: Icons.flash_on_rounded,
                    label: 'Capture <3s',
                    onTap: onOpenQuickCapture,
                    isPrimary: true,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // High Priority Tasks
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'High Priority Tasks',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
                TextButton(
                  onPressed: () => onNavigateTab(1),
                  child: const Text('View All'),
                ),
              ],
            ),
            if (urgentTasks.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(
                  'No urgent tasks pending. You are on track!',
                  style: TextStyle(color: Colors.grey.shade600),
                ),
              )
            else
              ...urgentTasks.map((t) => Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      leading: Checkbox(
                        value: t.status == 'completed',
                        onChanged: (_) => state.toggleTaskStatus(t.id),
                      ),
                      title: Text(
                        t.title,
                        style: TextStyle(
                          decoration: t.status == 'completed' ? TextDecoration.lineThrough : null,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      subtitle: t.dueDate != null
                          ? Text(
                              'Due: ${EthiopianCalendar.formatDual(t.dueDate!)}',
                              style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                            )
                          : null,
                      trailing: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: t.priority == 'urgent' ? Colors.red.shade100 : Colors.orange.shade100,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          t.priority.toUpperCase(),
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            color: t.priority == 'urgent' ? Colors.red.shade800 : Colors.orange.shade800,
                          ),
                        ),
                      ),
                    ),
                  )),

            const SizedBox(height: 24),

            // Upcoming Commitments Card
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Upcoming Commitments',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
                TextButton(
                  onPressed: () => onNavigateTab(2),
                  child: const Text('Manage'),
                ),
              ],
            ),
            if (pendingCommitments.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(
                  'No pending commitments due.',
                  style: TextStyle(color: Colors.grey.shade600),
                ),
              )
            else
              ...pendingCommitments.map((c) => Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      leading: const CircleAvatar(
                        backgroundColor: Color(0xFFE8F5E9),
                        child: Icon(Icons.receipt_long, color: Color(0xFF2E7D32)),
                      ),
                      title: Text(c.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text(
                        'Due: ${EthiopianCalendar.formatDual(c.dueDate)}',
                        style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                      ),
                      trailing: Text(
                        FinancialEngine.formatBirr(c.amountCents),
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                    ),
                  )),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _MetricCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.grey.withOpacity(0.2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isPrimary;

  const _ActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.isPrimary = false,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 16),
      label: Text(label),
      style: ElevatedButton.styleFrom(
        backgroundColor: isPrimary ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.surfaceVariant,
        foregroundColor: isPrimary ? Colors.white : Theme.of(context).colorScheme.onSurfaceVariant,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      ),
    );
  }
}
