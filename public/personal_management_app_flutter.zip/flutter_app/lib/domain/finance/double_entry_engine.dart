import 'dart:math';

/// Domain models and business logic for the Simplified Double-Entry Accounting Ledger.
///
/// Invariant: For every Journal Entry, Sum of Debits == Sum of Credits.
/// Units: Integer Minor Units (1 ETB = 100 cents / ሳንቲም).

enum AccountType { asset, liability, equity, income, expense }
enum EntryType { standard, transfer, debtIssuance, settlement, splitExpense, adjustment, writeOff }
enum PostingDirection { debit, credit }
enum DebtType { receivable, payable }
enum DebtStatus { active, settled, writtenOff }

class AccountModel {
  final String id;
  final String name;
  final AccountType type;
  final String currencyCode; // Default 'ETB'
  final bool isArchived;
  final DateTime createdAt;

  AccountModel({
    required this.id,
    required this.name,
    required this.type,
    this.currencyCode = 'ETB',
    this.isArchived = false,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now().toUtc();

  AccountModel copyWith({
    String? name,
    AccountType? type,
    String? currencyCode,
    bool? isArchived,
  }) {
    return AccountModel(
      id: id,
      name: name ?? this.name,
      type: type ?? this.type,
      currencyCode: currencyCode ?? this.currencyCode,
      isArchived: isArchived ?? this.isArchived,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'type': type.name,
    'currencyCode': currencyCode,
    'isArchived': isArchived,
    'createdAt': createdAt.toIso8601String(),
  };

  factory AccountModel.fromJson(Map<String, dynamic> json) => AccountModel(
    id: json['id'],
    name: json['name'],
    type: AccountType.values.firstWhere((e) => e.name == json['type']),
    currencyCode: json['currencyCode'] ?? 'ETB',
    isArchived: json['isArchived'] ?? false,
    createdAt: json['createdAt'] != null ? DateTime.parse(json['createdAt']) : null,
  );
}

class PartyModel {
  final String id;
  final String name;
  final String? phone;
  final String? notes;
  final bool isArchived;
  final DateTime createdAt;

  PartyModel({
    required this.id,
    required this.name,
    this.phone,
    this.notes,
    this.isArchived = false,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now().toUtc();

  PartyModel copyWith({
    String? name,
    String? phone,
    String? notes,
    bool? isArchived,
  }) {
    return PartyModel(
      id: id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      notes: notes ?? this.notes,
      isArchived: isArchived ?? this.isArchived,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'phone': phone,
    'notes': notes,
    'isArchived': isArchived,
    'createdAt': createdAt.toIso8601String(),
  };

  factory PartyModel.fromJson(Map<String, dynamic> json) => PartyModel(
    id: json['id'],
    name: json['name'],
    phone: json['phone'],
    notes: json['notes'],
    isArchived: json['isArchived'] ?? false,
    createdAt: json['createdAt'] != null ? DateTime.parse(json['createdAt']) : null,
  );
}

class JournalEntryModel {
  final String id;
  final EntryType entryType;
  final String description;
  final String occurrenceDate; // YYYY-MM-DD
  final bool isVoided;
  final String? voidReason;
  final DateTime createdAt;

  JournalEntryModel({
    required this.id,
    required this.entryType,
    required this.description,
    required this.occurrenceDate,
    this.isVoided = false,
    this.voidReason,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now().toUtc();

  JournalEntryModel copyWith({
    bool? isVoided,
    String? voidReason,
  }) {
    return JournalEntryModel(
      id: id,
      entryType: entryType,
      description: description,
      occurrenceDate: occurrenceDate,
      isVoided: isVoided ?? this.isVoided,
      voidReason: voidReason ?? this.voidReason,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'entryType': entryType.name,
    'description': description,
    'occurrenceDate': occurrenceDate,
    'isVoided': isVoided,
    'voidReason': voidReason,
    'createdAt': createdAt.toIso8601String(),
  };

  factory JournalEntryModel.fromJson(Map<String, dynamic> json) => JournalEntryModel(
    id: json['id'],
    entryType: EntryType.values.firstWhere((e) => e.name == json['entryType']),
    description: json['description'],
    occurrenceDate: json['occurrenceDate'],
    isVoided: json['isVoided'] ?? false,
    voidReason: json['voidReason'],
    createdAt: json['createdAt'] != null ? DateTime.parse(json['createdAt']) : null,
  );
}

class PostingModel {
  final String id;
  final String entryId;
  final String accountId;
  final int amountCents; // Strictly > 0
  final PostingDirection direction;
  final String accountMovementDate; // YYYY-MM-DD
  final String? categoryId;
  final String? note;

  PostingModel({
    required this.id,
    required this.entryId,
    required this.accountId,
    required this.amountCents,
    required this.direction,
    required this.accountMovementDate,
    this.categoryId,
    this.note,
  }) {
    if (amountCents <= 0) {
      throw ArgumentError('Posting amount must be strictly greater than 0, got $amountCents');
    }
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'entryId': entryId,
    'accountId': accountId,
    'amountCents': amountCents,
    'direction': direction.name,
    'accountMovementDate': accountMovementDate,
    'categoryId': categoryId,
    'note': note,
  };

  factory PostingModel.fromJson(Map<String, dynamic> json) => PostingModel(
    id: json['id'],
    entryId: json['entryId'],
    accountId: json['accountId'],
    amountCents: json['amountCents'],
    direction: PostingDirection.values.firstWhere((e) => e.name == json['direction']),
    accountMovementDate: json['accountMovementDate'],
    categoryId: json['categoryId'],
    note: json['note'],
  );
}

class DebtModel {
  final String id;
  final String originEntryId;
  final String partyId;
  final DebtType debtType;
  final int principalCents;
  final int outstandingCents;
  final String? dueDate;
  final DebtStatus status;
  final DateTime createdAt;

  DebtModel({
    required this.id,
    required this.originEntryId,
    required this.partyId,
    required this.debtType,
    required this.principalCents,
    required this.outstandingCents,
    this.dueDate,
    this.status = DebtStatus.active,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now().toUtc();

  DebtModel copyWith({
    int? outstandingCents,
    DebtStatus? status,
  }) {
    return DebtModel(
      id: id,
      originEntryId: originEntryId,
      partyId: partyId,
      debtType: debtType,
      principalCents: principalCents,
      outstandingCents: outstandingCents ?? this.outstandingCents,
      dueDate: dueDate,
      status: status ?? this.status,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'originEntryId': originEntryId,
    'partyId': partyId,
    'debtType': debtType.name,
    'principalCents': principalCents,
    'outstandingCents': outstandingCents,
    'dueDate': dueDate,
    'status': status.name,
    'createdAt': createdAt.toIso8601String(),
  };

  factory DebtModel.fromJson(Map<String, dynamic> json) => DebtModel(
    id: json['id'],
    originEntryId: json['originEntryId'],
    partyId: json['partyId'],
    debtType: DebtType.values.firstWhere((e) => e.name == json['debtType']),
    principalCents: json['principalCents'],
    outstandingCents: json['outstandingCents'],
    dueDate: json['dueDate'],
    status: DebtStatus.values.firstWhere((e) => e.name == json['status']),
    createdAt: json['createdAt'] != null ? DateTime.parse(json['createdAt']) : null,
  );
}

class SettlementAllocationModel {
  final String id;
  final String settlementEntryId;
  final String debtId;
  final int allocatedCents;
  final String settlementDate;

  SettlementAllocationModel({
    required this.id,
    required this.settlementEntryId,
    required this.debtId,
    required this.allocatedCents,
    required this.settlementDate,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'settlementEntryId': settlementEntryId,
    'debtId': debtId,
    'allocatedCents': allocatedCents,
    'settlementDate': settlementDate,
  };

  factory SettlementAllocationModel.fromJson(Map<String, dynamic> json) => SettlementAllocationModel(
    id: json['id'],
    settlementEntryId: json['settlementEntryId'],
    debtId: json['debtId'],
    allocatedCents: json['allocatedCents'],
    settlementDate: json['settlementDate'],
  );
}

// ----------------------------------------------------------------------------
// Double-Entry Engine & Calculation Formulas
// ----------------------------------------------------------------------------

class DoubleEntryEngine {
  /// Validates that a journal entry is perfectly balanced: Sum Debits == Sum Credits
  static void validateBalancedEntry(List<PostingModel> postings) {
    if (postings.length < 2) {
      throw StateError('A balanced journal entry must contain at least 2 postings.');
    }

    int totalDebits = 0;
    int totalCredits = 0;

    for (final p in postings) {
      if (p.direction == PostingDirection.debit) {
        totalDebits += p.amountCents;
      } else {
        totalCredits += p.amountCents;
      }
    }

    if (totalDebits != totalCredits) {
      throw StateError(
        'Ledger Invariant Violated: Debits ($totalDebits) != Credits ($totalCredits). Difference: ${(totalDebits - totalCredits).abs()} cents',
      );
    }
  }

  /// Calculates the real reconstructed balance of an account from postings.
  /// If [entries] or [voidedEntryIds] is provided, postings from voided entries are strictly ignored.
  static int calculateAccountBalance({
    required AccountModel account,
    required List<PostingModel> postings,
    String? asOfDate,
    List<JournalEntryModel>? entries,
    Set<String>? voidedEntryIds,
  }) {
    final effectiveVoidedIds = voidedEntryIds ??
        (entries != null
            ? entries.where((e) => e.isVoided).map((e) => e.id).toSet()
            : const <String>{});

    int balance = 0;
    for (final p in postings) {
      if (p.accountId != account.id) continue;
      if (effectiveVoidedIds.contains(p.entryId)) continue;
      if (asOfDate != null && p.accountMovementDate.compareTo(asOfDate) > 0) continue;

      if (account.type == AccountType.asset || account.type == AccountType.expense) {
        balance += (p.direction == PostingDirection.debit) ? p.amountCents : -p.amountCents;
      } else {
        balance += (p.direction == PostingDirection.credit) ? p.amountCents : -p.amountCents;
      }
    }
    return balance;
  }

  /// Total liquid cash across all bank, cash, and mobile money asset accounts.
  static int calculateLiquidCash({
    required List<AccountModel> accounts,
    required List<PostingModel> postings,
    List<JournalEntryModel>? entries,
  }) {
    final effectiveVoidedIds = entries != null
        ? entries.where((e) => e.isVoided).map((e) => e.id).toSet()
        : const <String>{};

    final liquidAccounts = accounts.where(
      (a) => a.type == AccountType.asset && !a.isArchived && !a.name.toLowerCase().contains('receivable'),
    );
    int sum = 0;
    for (final acc in liquidAccounts) {
      sum += calculateAccountBalance(
        account: acc,
        postings: postings,
        voidedEntryIds: effectiveVoidedIds,
      );
    }
    return sum;
  }

  /// Net Financial Position = Total Assets - Total Liabilities
  static int calculateNetPosition({
    required List<AccountModel> accounts,
    required List<PostingModel> postings,
    List<JournalEntryModel>? entries,
  }) {
    final effectiveVoidedIds = entries != null
        ? entries.where((e) => e.isVoided).map((e) => e.id).toSet()
        : const <String>{};

    int totalAssets = 0;
    int totalLiabilities = 0;

    for (final acc in accounts) {
      final bal = calculateAccountBalance(
        account: acc,
        postings: postings,
        voidedEntryIds: effectiveVoidedIds,
      );
      if (acc.type == AccountType.asset) {
        totalAssets += bal;
      } else if (acc.type == AccountType.liability) {
        totalLiabilities += bal;
      }
    }
    return totalAssets - totalLiabilities;
  }

  /// Available to Spend Safe Harbor Formula:
  /// Available to Spend = Total Liquid Cash
  ///                     - Unpaid Payables Due in Current Period
  ///                     - Reserved Savings Allocations
  /// Note: Receivables are STRICTLY EXCLUDED.
  static int calculateAvailableToSpend({
    required int liquidCashCents,
    required int unpaidPayablesDueInPeriodCents,
    required int reservedSavingsCents,
  }) {
    return liquidCashCents - unpaidPayablesDueInPeriodCents - reservedSavingsCents;
  }

  // --------------------------------------------------------------------------
  // Plain-Language Transaction Constructors (Double-Entry Under the Hood)
  // --------------------------------------------------------------------------

  /// Example A: Someone pays my expense on Day 1
  /// Debit Expense, Credit Liability (Payable).
  static Map<String, dynamic> buildThirdPartyPaidExpense({
    required String entryId,
    required String debtId,
    required String partyId,
    required String expenseAccountId,
    required String payableAccountId,
    required int amountCents,
    required String occurrenceDate,
    String? dueDate,
    required String description,
    String? categoryId,
  }) {
    final entry = JournalEntryModel(
      id: entryId,
      entryType: EntryType.debtIssuance,
      description: description,
      occurrenceDate: occurrenceDate,
    );

    final postings = [
      PostingModel(
        id: '$entryId-dr-exp',
        entryId: entryId,
        accountId: expenseAccountId,
        amountCents: amountCents,
        direction: PostingDirection.debit,
        accountMovementDate: occurrenceDate,
        categoryId: categoryId,
      ),
      PostingModel(
        id: '$entryId-cr-payable',
        entryId: entryId,
        accountId: payableAccountId,
        amountCents: amountCents,
        direction: PostingDirection.credit,
        accountMovementDate: occurrenceDate,
      ),
    ];

    validateBalancedEntry(postings);

    final debt = DebtModel(
      id: debtId,
      originEntryId: entryId,
      partyId: partyId,
      debtType: DebtType.payable,
      principalCents: amountCents,
      outstandingCents: amountCents,
      dueDate: dueDate,
      status: DebtStatus.active,
    );

    return {'entry': entry, 'postings': postings, 'debt': debt};
  }

  /// Example B: I lend money
  /// Debit Asset (Receivable), Credit Asset (Cash). Zero expense!
  static Map<String, dynamic> buildLendMoney({
    required String entryId,
    required String debtId,
    required String partyId,
    required String receivableAccountId,
    required String sourceAssetAccountId,
    required int amountCents,
    required String date,
    String? dueDate,
    required String description,
  }) {
    final entry = JournalEntryModel(
      id: entryId,
      entryType: EntryType.debtIssuance,
      description: description,
      occurrenceDate: date,
    );

    final postings = [
      PostingModel(
        id: '$entryId-dr-rec',
        entryId: entryId,
        accountId: receivableAccountId,
        amountCents: amountCents,
        direction: PostingDirection.debit,
        accountMovementDate: date,
      ),
      PostingModel(
        id: '$entryId-cr-cash',
        entryId: entryId,
        accountId: sourceAssetAccountId,
        amountCents: amountCents,
        direction: PostingDirection.credit,
        accountMovementDate: date,
      ),
    ];

    validateBalancedEntry(postings);

    final debt = DebtModel(
      id: debtId,
      originEntryId: entryId,
      partyId: partyId,
      debtType: DebtType.receivable,
      principalCents: amountCents,
      outstandingCents: amountCents,
      dueDate: dueDate,
      status: DebtStatus.active,
    );

    return {'entry': entry, 'postings': postings, 'debt': debt};
  }

  /// Example C: I borrow money
  /// Debit Asset (Telebirr/Cash), Credit Liability (Payable). Zero income!
  static Map<String, dynamic> buildBorrowMoney({
    required String entryId,
    required String debtId,
    required String partyId,
    required String destAssetAccountId,
    required String payableAccountId,
    required int amountCents,
    required String date,
    String? dueDate,
    required String description,
  }) {
    final entry = JournalEntryModel(
      id: entryId,
      entryType: EntryType.debtIssuance,
      description: description,
      occurrenceDate: date,
    );

    final postings = [
      PostingModel(
        id: '$entryId-dr-asset',
        entryId: entryId,
        accountId: destAssetAccountId,
        amountCents: amountCents,
        direction: PostingDirection.debit,
        accountMovementDate: date,
      ),
      PostingModel(
        id: '$entryId-cr-payable',
        entryId: entryId,
        accountId: payableAccountId,
        amountCents: amountCents,
        direction: PostingDirection.credit,
        accountMovementDate: date,
      ),
    ];

    validateBalancedEntry(postings);

    final debt = DebtModel(
      id: debtId,
      originEntryId: entryId,
      partyId: partyId,
      debtType: DebtType.payable,
      principalCents: amountCents,
      outstandingCents: amountCents,
      dueDate: dueDate,
      status: DebtStatus.active,
    );

    return {'entry': entry, 'postings': postings, 'debt': debt};
  }

  /// Example D: Split expense
  /// Debit Expense (myShare), Debit Receivable (theirShare), Credit Asset (total paid).
  static Map<String, dynamic> buildSplitExpense({
    required String entryId,
    required String debtId,
    required String partyId,
    required String myExpenseAccountId,
    required String receivableAccountId,
    required String paidAssetAccountId,
    required int myShareCents,
    required int theirShareCents,
    required String occurrenceDate,
    String? dueDate,
    required String description,
    String? categoryId,
  }) {
    final total = myShareCents + theirShareCents;
    final entry = JournalEntryModel(
      id: entryId,
      entryType: EntryType.splitExpense,
      description: description,
      occurrenceDate: occurrenceDate,
    );

    final postings = [
      PostingModel(
        id: '$entryId-dr-exp',
        entryId: entryId,
        accountId: myExpenseAccountId,
        amountCents: myShareCents,
        direction: PostingDirection.debit,
        accountMovementDate: occurrenceDate,
        categoryId: categoryId,
      ),
      PostingModel(
        id: '$entryId-dr-rec',
        entryId: entryId,
        accountId: receivableAccountId,
        amountCents: theirShareCents,
        direction: PostingDirection.debit,
        accountMovementDate: occurrenceDate,
      ),
      PostingModel(
        id: '$entryId-cr-cash',
        entryId: entryId,
        accountId: paidAssetAccountId,
        amountCents: total,
        direction: PostingDirection.credit,
        accountMovementDate: occurrenceDate,
      ),
    ];

    validateBalancedEntry(postings);

    final debt = DebtModel(
      id: debtId,
      originEntryId: entryId,
      partyId: partyId,
      debtType: DebtType.receivable,
      principalCents: theirShareCents,
      outstandingCents: theirShareCents,
      dueDate: dueDate,
      status: DebtStatus.active,
    );

    return {'entry': entry, 'postings': postings, 'debt': debt};
  }

  /// Account Transfer with optional transaction fee
  /// Generates balanced postings:
  /// Dr Destination (transfer amount)
  /// Dr Bank Fee Expense (fee amount, if any)
  /// Cr Source (transfer amount + fee)
  static Map<String, dynamic> buildTransfer({
    required String entryId,
    required String fromAssetAccountId,
    required String toAssetAccountId,
    required int amountCents,
    required String date,
    required String description,
    int transferFeeCents = 0,
    String? feeExpenseAccountId,
    String? note,
  }) {
    final entry = JournalEntryModel(
      id: entryId,
      entryType: EntryType.transfer,
      description: transferFeeCents > 0
          ? '$description (Fee: ${(transferFeeCents / 100).toStringAsFixed(2)} ETB)'
          : description,
      occurrenceDate: date,
    );

    final postings = <PostingModel>[
      PostingModel(
        id: '$entryId-dr-dest',
        entryId: entryId,
        accountId: toAssetAccountId,
        amountCents: amountCents,
        direction: PostingDirection.debit,
        accountMovementDate: date,
        note: note,
      ),
    ];

    if (transferFeeCents > 0 && feeExpenseAccountId != null) {
      postings.add(
        PostingModel(
          id: '$entryId-dr-fee',
          entryId: entryId,
          accountId: feeExpenseAccountId,
          amountCents: transferFeeCents,
          direction: PostingDirection.debit,
          accountMovementDate: date,
          note: 'Transfer service fee',
        ),
      );
    }

    postings.add(
      PostingModel(
        id: '$entryId-cr-source',
        entryId: entryId,
        accountId: fromAssetAccountId,
        amountCents: amountCents + transferFeeCents,
        direction: PostingDirection.credit,
        accountMovementDate: date,
        note: note,
      ),
    );

    validateBalancedEntry(postings);
    return {'entry': entry, 'postings': postings};
  }

  /// Voids an existing journal entry with an audit reason
  static JournalEntryModel buildVoidEntry({
    required JournalEntryModel entry,
    required String reason,
  }) {
    return entry.copyWith(
      isVoided: true,
      voidReason: reason,
    );
  }

  /// Example E: Debt Settlement with optional separate interest
  static Map<String, dynamic> buildDebtSettlement({
    required String settlementEntryId,
    required DebtModel debt,
    required String settlementAssetAccountId,
    required String debtAccountId, // Receivable (Asset) or Payable (Liability)
    required int allocatedPrincipalCents,
    int interestCents = 0,
    String? interestAccountId,
    required String settlementDate,
    required String description,
  }) {
    final entry = JournalEntryModel(
      id: settlementEntryId,
      entryType: EntryType.settlement,
      description: description,
      occurrenceDate: settlementDate,
    );

    final postings = <PostingModel>[];
    final isPayable = debt.debtType == DebtType.payable;

    if (isPayable) {
      // Repaying payable: Debit Payable, Credit Asset
      postings.add(
        PostingModel(
          id: '$settlementEntryId-dr-payable',
          entryId: settlementEntryId,
          accountId: debtAccountId,
          amountCents: allocatedPrincipalCents,
          direction: PostingDirection.debit,
          accountMovementDate: settlementDate,
        ),
      );

      if (interestCents > 0 && interestAccountId != null) {
        postings.add(
          PostingModel(
            id: '$settlementEntryId-dr-interest',
            entryId: settlementEntryId,
            accountId: interestAccountId,
            amountCents: interestCents,
            direction: PostingDirection.debit,
            accountMovementDate: settlementDate,
          ),
        );
      }

      postings.add(
        PostingModel(
          id: '$settlementEntryId-cr-asset',
          entryId: settlementEntryId,
          accountId: settlementAssetAccountId,
          amountCents: allocatedPrincipalCents + interestCents,
          direction: PostingDirection.credit,
          accountMovementDate: settlementDate,
        ),
      );
    } else {
      // Collecting receivable: Debit Asset, Credit Receivable
      postings.add(
        PostingModel(
          id: '$settlementEntryId-dr-asset',
          entryId: settlementEntryId,
          accountId: settlementAssetAccountId,
          amountCents: allocatedPrincipalCents + interestCents,
          direction: PostingDirection.debit,
          accountMovementDate: settlementDate,
        ),
      );

      postings.add(
        PostingModel(
          id: '$settlementEntryId-cr-rec',
          entryId: settlementEntryId,
          accountId: debtAccountId,
          amountCents: allocatedPrincipalCents,
          direction: PostingDirection.credit,
          accountMovementDate: settlementDate,
        ),
      );

      if (interestCents > 0 && interestAccountId != null) {
        postings.add(
          PostingModel(
            id: '$settlementEntryId-cr-interest',
            entryId: settlementEntryId,
            accountId: interestAccountId,
            amountCents: interestCents,
            direction: PostingDirection.credit,
            accountMovementDate: settlementDate,
          ),
        );
      }
    }

    validateBalancedEntry(postings);

    final allocation = SettlementAllocationModel(
      id: 'alloc-$settlementEntryId',
      settlementEntryId: settlementEntryId,
      debtId: debt.id,
      allocatedCents: allocatedPrincipalCents,
      settlementDate: settlementDate,
    );

    final newOutstanding = max(0, debt.outstandingCents - allocatedPrincipalCents);
    final updatedDebt = debt.copyWith(
      outstandingCents: newOutstanding,
      status: newOutstanding == 0 ? DebtStatus.settled : DebtStatus.active,
    );

    return {
      'entry': entry,
      'postings': postings,
      'allocation': allocation,
      'updatedDebt': updatedDebt,
    };
  }
}
