import 'ethiopian_date.dart';

/// Algorithmic converter between Gregorian (CE) and Ethiopian (Amete Mihret) calendar dates.
///
/// Uses Julian Day Number (JDN) intermediate representation to ensure mathematical
/// precision across all leap-year cycles, century boundaries, and Pagume transitions.
class EthiopianCalendar {
  // Ethiopian calendar epoch in Julian Day Number (JDN):
  // Meskerem 1, 1 E.C. = JDN 1724221
  static const int _jdEpochOffset = 1724221;

  /// Converts a Gregorian [DateTime] to [EthiopianDate].
  static EthiopianDate fromGregorian(DateTime gregorian) {
    final jdn = _gregorianToJdn(gregorian.year, gregorian.month, gregorian.day);
    return _jdnToEthiopian(jdn);
  }

  /// Converts an [EthiopianDate] back to a Gregorian [DateTime].
  static DateTime toGregorian(EthiopianDate ethiopian) {
    final jdn = _ethiopianToJdn(ethiopian.year, ethiopian.month, ethiopian.day);
    return _jdnToGregorian(jdn);
  }

  /// Calculates Julian Day Number from a Gregorian calendar date.
  static int _gregorianToJdn(int year, int month, int day) {
    int a = (14 - month) ~/ 12;
    int y = year + 4800 - a;
    int m = month + 12 * a - 3;
    return day + ((153 * m + 2) ~/ 5) + 365 * y + (y ~/ 4) - (y ~/ 100) + (y ~/ 400) - 32045;
  }

  /// Converts a Julian Day Number to Gregorian calendar components.
  static DateTime _jdnToGregorian(int jdn) {
    int a = jdn + 32044;
    int b = (4 * a + 3) ~/ 146097;
    int c = a - (146097 * b) ~/ 4;
    int d = (4 * c + 3) ~/ 1461;
    int e = c - (1461 * d) ~/ 4;
    int m = (5 * e + 2) ~/ 153;

    int day = e - ((153 * m + 2) ~/ 5) + 1;
    int month = m + 3 - 12 * (m ~/ 10);
    int year = 100 * b + d - 4800 + (m ~/ 10);

    return DateTime.utc(year, month, day);
  }

  /// Converts a Julian Day Number to Ethiopian calendar components.
  static EthiopianDate _jdnToEthiopian(int jdn) {
    int days = jdn - _jdEpochOffset;
    int y0 = (4 * days) ~/ 1461;

    while (days < 365 * y0 + ((y0 + 1) ~/ 4)) {
      y0--;
    }
    while (days >= 365 * (y0 + 1) + ((y0 + 2) ~/ 4)) {
      y0++;
    }

    int year = y0 + 1;
    int dayOfYear = days - (365 * y0 + ((y0 + 1) ~/ 4));

    int month = (dayOfYear ~/ 30) + 1;
    int day = (dayOfYear % 30) + 1;

    // Handle Pagumē boundary (Month 13)
    if (month > 13) {
      month = 13;
    }

    return EthiopianDate(year: year, month: month, day: day);
  }

  /// Converts Ethiopian date components to Julian Day Number.
  static int _ethiopianToJdn(int year, int month, int day) {
    int y0 = year - 1;
    int leapDays = (y0 + 1) ~/ 4;
    return _jdEpochOffset + 365 * y0 + leapDays + (month - 1) * 30 + (day - 1);
  }

  /// Formats a Gregorian date into a dual-calendar string representation.
  /// Example output: "ጥቅምት 28, 2017 (Nov 07, 2024)"
  static String formatDual(DateTime date, {bool useAmharic = true}) {
    final eth = fromGregorian(date);
    final ethStr = useAmharic ? eth.toAmharicString(includeEra: false) : eth.toEnglishString(includeEra: false);
    final gregMonthNames = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    final gregStr = '${gregMonthNames[date.month - 1]} ${date.day.toString().padLeft(2, '0')}, ${date.year}';
    return '$ethStr ($gregStr)';
  }

  /// Returns today's Ethiopian date based on local time.
  static EthiopianDate now() {
    return fromGregorian(DateTime.now());
  }
}
