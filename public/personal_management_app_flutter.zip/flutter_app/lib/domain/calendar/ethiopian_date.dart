/// Represents a date in the Ethiopian Calendar (Ge'ez: የቀን መቁጠሪያ).
///
/// In the Ethiopian calendar:
/// - A year consists of 12 months of 30 days each (Meskerem through Nehase)
/// - Followed by a 13th month, Pagumē (ጳጉሜ), of 5 days (6 days in a leap year)
/// - Ethiopian New Year (Enkutatash) falls on September 11 (or September 12 in Gregorian leap years preceding Ethiopian leap years).
class EthiopianDate {
  final int year;
  final int month; // 1 to 13
  final int day; // 1 to 30 (1 to 5 or 6 for Pagumē)

  const EthiopianDate({
    required this.year,
    required this.month,
    required this.day,
  })  : assert(month >= 1 && month <= 13, 'Month must be between 1 and 13'),
        assert(day >= 1 && day <= 30, 'Day must be between 1 and 30');

  /// Names of Ethiopian months in Amharic script.
  static const List<String> amharicMonths = [
    'መስከረም', // Meskerem (1)
    'ጥቅምት',  // Tikimt (2)
    'ኅዳር',   // Hidar (3)
    'ታኅሣሥ',  // Tahsas (4)
    'ጥር',     // Tir (5)
    'የካቲት',  // Yekatit (6)
    'መጋቢት',  // Megabit (7)
    'ሚያዝያ',  // Miyazya (8)
    'ግንቦት',  // Ginbot (9)
    'ሰኔ',     // Sene (10)
    'ሐምሌ',   // Hamle (11)
    'ነሐሴ',   // Nehase (12)
    'ጳጉሜ',   // Pagume (13)
  ];

  /// Phonetic transliterations of Ethiopian months in English.
  static const List<String> englishMonths = [
    'Meskerem',
    'Tikimt',
    'Hidar',
    'Tahsas',
    'Tir',
    'Yekatit',
    'Megabit',
    'Miyazya',
    'Ginbot',
    'Sene',
    'Hamle',
    'Nehase',
    'Pagume',
  ];

  /// Whether this Ethiopian year is a leap year (has 6 days in Pagumē).
  /// In the Ethiopian calendar, a leap year occurs every 4 years when year % 4 == 3.
  bool get isLeapYear => (year % 4) == 3;

  /// Maximum days in this particular month.
  int get daysInMonth {
    if (month == 13) {
      return isLeapYear ? 6 : 5;
    }
    return 30;
  }

  /// Month name in Amharic.
  String get amharicMonthName => amharicMonths[month - 1];

  /// Month name in English transliteration.
  String get englishMonthName => englishMonths[month - 1];

  /// Formatted date in Amharic: e.g. "ጥቅምት 28, 2017 ዓ.ም."
  String toAmharicString({bool includeEra = true}) {
    final era = includeEra ? ' ዓ.ም.' : '';
    return '$amharicMonthName $day, $year$era';
  }

  /// Formatted date in English transliteration: e.g. "Tikimt 28, 2017 E.C."
  String toEnglishString({bool includeEra = true}) {
    final era = includeEra ? ' E.C.' : '';
    return '$englishMonthName $day, $year$era';
  }

  @override
  String toString() => '$year-${month.toString().padLeft(2, '0')}-${day.toString().padLeft(2, '0')}';

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is EthiopianDate &&
          runtimeType == other.runtimeType &&
          year == other.year &&
          month == other.month &&
          day == other.day;

  @override
  int get hashCode => year.hashCode ^ month.hashCode ^ day.hashCode;
}
