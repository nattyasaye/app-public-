import 'dart:async';

/// Abstract contract for local device notifications across Android and iOS.
///
/// Android: Implemented via [AndroidNotificationChannel] with exact alarm permissions
/// iOS: Implemented via [UNUserNotificationCenter]
abstract class INotificationService {
  Future<void> initialize();
  Future<bool> requestPermissions();
  Future<void> scheduleReminder({
    required String id,
    required String title,
    required String body,
    required DateTime scheduledDateUtc,
    String? payload,
  });
  Future<void> cancelReminder(String id);
  Future<void> cancelAllReminders();
}

/// Abstract contract for secure credential and key storage.
///
/// Android: Hardware-backed Android Keystore
/// iOS: Apple Keychain Services
abstract class ISecureStorageService {
  Future<void> writeSecret(String key, String value);
  Future<String?> readSecret(String key);
  Future<void> deleteSecret(String key);
  Future<bool> hasKey(String key);
}

/// Abstract contract for encrypted database backup and restoration.
abstract class IBackupService {
  /// Generates an encrypted snapshot archive of the local SQLite database.
  Future<String> createEncryptedBackup({
    required String passphrase,
    required String destinationDirectoryPath,
  });

  /// Restores database state from an encrypted archive using the user's passphrase.
  Future<bool> restoreFromEncryptedBackup({
    required String archiveFilePath,
    required String passphrase,
  });

  /// Verifies integrity and header metadata of an archive without applying it.
  Future<BackupMetadata> inspectBackupArchive(String archiveFilePath);
}

/// Metadata header stored inside a backup archive.
class BackupMetadata {
  final int schemaVersion;
  final String appVersion;
  final DateTime createdAtUtc;
  final String saltHex;
  final String ivHex;
  final String sha256Checksum;

  const BackupMetadata({
    required this.schemaVersion,
    required this.appVersion,
    required this.createdAtUtc,
    required this.saltHex,
    required this.ivHex,
    required this.sha256Checksum,
  });
}

/// Abstract contract for syncing state with Home-Screen widgets.
///
/// Android: AppWidgetProvider / Glance
/// iOS: WidgetKit (TimelineProvider)
abstract class IWidgetSyncService {
  Future<void> updateQuickCaptureWidget();
  Future<void> updateTodayTasksWidget({required int taskCount, required List<String> taskTitles});
}
